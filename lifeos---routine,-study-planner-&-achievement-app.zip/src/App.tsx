/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import { User } from 'firebase/auth';
import {
  AchievementBadge,
  AppNotification,
  FocusSession,
  MonthlyGoal,
  PersonalReward,
  RoutineItem,
  TaskRecord,
  UserSettings,
} from './types';
import { StorageService } from './services/storage';
import { playChime } from './services/audio';
import { checkAndTriggerReminders } from './services/notifications';
import { calculateStreak, fireCelebrationConfetti } from './services/gamification';
import { getTodayDateString } from './utils/schedule';
import { subscribeToAuthState, testFirestoreConnection } from './services/firebase';
import { CloudSyncService, SyncStatus } from './services/cloudSync';
import { applyTheme } from './utils/theme';

import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { AuthModal } from './components/auth/AuthModal';
import { OnboardingModal } from './components/auth/OnboardingModal';

import { DashboardView } from './views/DashboardView';
import { RoutineView } from './views/RoutineView';
import { CalendarView } from './views/CalendarView';
import { TasksView } from './views/TasksView';
import { RoadmapView } from './views/RoadmapView';
import { FocusTimerView } from './views/FocusTimerView';
import { AchievementsView } from './views/AchievementsView';
import { AnalyticsView } from './views/AnalyticsView';
import { NotificationsView } from './views/NotificationsView';
import { SettingsView } from './views/SettingsView';

export default function App() {
  // Auth & Cloud Sync States
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('local_only');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState(false);

  // Application Data States
  const [settings, setSettings] = useState<UserSettings>(() => StorageService.getSettings());
  const [routineItems, setRoutineItems] = useState<RoutineItem[]>(() => StorageService.getRoutine());
  const [taskRecords, setTaskRecords] = useState<TaskRecord[]>(() => StorageService.getTasks());
  const [monthlyGoals, setMonthlyGoals] = useState<MonthlyGoal[]>(() => StorageService.getGoals());
  const [focusSessions, setFocusSessions] = useState<FocusSession[]>(() => StorageService.getFocusSessions());
  const [badges, setBadges] = useState<AchievementBadge[]>(() => StorageService.getBadges());
  const [personalRewards, setPersonalRewards] = useState<PersonalReward[]>(() => StorageService.getRewards());
  const [notifications, setNotifications] = useState<AppNotification[]>(() => StorageService.getNotifications());
  const [totalXp, setTotalXp] = useState<number>(() => StorageService.getTotalXp());

  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>('dashboard');

  // Preselected focus session task state
  const [focusTaskTitle, setFocusTaskTitle] = useState<string>('Competitive Programming Practice');
  const [focusTaskCategory, setFocusTaskCategory] = useState<string>('Competitive Programming');

  // Apply theme dynamically (supports light, dark, and system preference)
  useEffect(() => {
    applyTheme(settings.theme);

    if (settings.theme === 'system' && typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme('system');
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [settings.theme]);

  // Network online/offline status observer
  useEffect(() => {
    const handleOnline = () => {
      if (currentUser) setSyncStatus('synced');
    };
    const handleOffline = () => {
      setSyncStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [currentUser]);

  // Subscribe to Firebase Auth and synchronize user data
  useEffect(() => {
    testFirestoreConnection();

    const unsubscribe = subscribeToAuthState(async (user) => {
      setCurrentUser(user);
      if (user) {
        setSyncStatus('syncing');
        try {
          // Sync profile info
          await CloudSyncService.syncUserProfile(user);

          // Fetch user's data from Firestore
          const cloudData = await CloudSyncService.fetchAllUserData(user.uid);

          if (cloudData.isNewAccount) {
            // First time login: Prompt onboarding to setup profile & migrate local data
            setIsOnboardingModalOpen(true);
            setSyncStatus('synced');
          } else {
            // Returning user: Load cloud state
            if (cloudData.settings) {
              const mergedSettings = { ...cloudData.settings, displayName: user.displayName || cloudData.settings.displayName };
              setSettings(mergedSettings);
              StorageService.saveSettings(mergedSettings);

              const cloudXp = (cloudData.settings as unknown as { totalXp?: number }).totalXp;
              if (typeof cloudXp === 'number') {
                setTotalXp(cloudXp);
                StorageService.saveTotalXp(cloudXp);
              }
            }
            if (cloudData.routines.length > 0) {
              setRoutineItems(cloudData.routines);
              StorageService.saveRoutine(cloudData.routines);
            }
            if (cloudData.tasks.length > 0) {
              setTaskRecords(cloudData.tasks);
              StorageService.saveTasks(cloudData.tasks);
            }
            if (cloudData.goals.length > 0) {
              setMonthlyGoals(cloudData.goals);
              StorageService.saveGoals(cloudData.goals);
            }
            if (cloudData.focusSessions.length > 0) {
              setFocusSessions(cloudData.focusSessions);
              StorageService.saveFocusSessions(cloudData.focusSessions);
            }
            if (cloudData.badges.length > 0) {
              setBadges(cloudData.badges);
              StorageService.saveBadges(cloudData.badges);
            }
            setSyncStatus('synced');
          }
        } catch (err) {
          console.error('Error synchronizing cloud data:', err);
          setSyncStatus('error');
        }
      } else {
        setSyncStatus('local_only');
      }
    });

    return () => unsubscribe();
  }, []);

  // Periodic reminder checking
  useEffect(() => {
    const handleNewNotification = (newNotif: AppNotification) => {
      setNotifications((prev) => {
        const updated = [newNotif, ...prev];
        StorageService.saveNotifications(updated);
        return updated;
      });
    };

    const interval = setInterval(() => {
      checkAndTriggerReminders(routineItems, settings, handleNewNotification);
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [routineItems, settings]);

  // Calculate Streak
  const streakInfo = calculateStreak(taskRecords);

  // Today's task counters for Navbar & Sidebar
  const todayStr = getTodayDateString();
  const todayDayOfWeek = new Date().getDay();
  const todayScheduled = routineItems.filter((i) => {
    if (!i.isRecurring && i.specificDate) return i.specificDate === todayStr;
    return i.daysOfWeek.includes(todayDayOfWeek);
  });
  const todayRecords = taskRecords.filter((t) => t.date === todayStr);
  const completedTodayCount = todayRecords.filter((t) => t.status === 'completed').length;

  // Manual Cloud Sync Trigger
  const handleManualSync = async () => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setSyncStatus('syncing');
    try {
      const cloudData = await CloudSyncService.fetchAllUserData(currentUser.uid);
      if (cloudData.settings) setSettings(cloudData.settings);
      if (cloudData.routines.length > 0) setRoutineItems(cloudData.routines);
      if (cloudData.tasks.length > 0) setTaskRecords(cloudData.tasks);
      if (cloudData.goals.length > 0) setMonthlyGoals(cloudData.goals);
      if (cloudData.focusSessions.length > 0) setFocusSessions(cloudData.focusSessions);
      if (cloudData.badges.length > 0) setBadges(cloudData.badges);
      setSyncStatus('synced');
    } catch {
      setSyncStatus('error');
    }
  };

  // Sign out handler
  const handleSignOut = () => {
    setCurrentUser(null);
    setSyncStatus('local_only');
    // Reload local guest state
    setSettings(StorageService.getSettings());
    setRoutineItems(StorageService.getRoutine());
    setTaskRecords(StorageService.getTasks());
    setMonthlyGoals(StorageService.getGoals());
  };

  // First-time Onboarding Complete Handler
  const handleOnboardingComplete = async (
    configuredSettings: Partial<UserSettings>,
    shouldMigrateLocalData: boolean
  ) => {
    if (!currentUser) return;
    setIsOnboardingModalOpen(false);
    setSyncStatus('syncing');

    const newSettings: UserSettings = {
      ...settings,
      ...configuredSettings,
      displayName: configuredSettings.displayName || currentUser.displayName || 'Alex',
    };
    setSettings(newSettings);
    StorageService.saveSettings(newSettings);

    try {
      if (shouldMigrateLocalData) {
        // Upload current browser state to Cloud Firestore
        await CloudSyncService.uploadFullLocalDataToCloud(currentUser.uid, {
          routines: routineItems,
          tasks: taskRecords,
          goals: monthlyGoals,
          focusSessions,
          badges,
          settings: newSettings,
          totalXp,
        });
      } else {
        // Initialize with default template in cloud
        await CloudSyncService.saveSettings(currentUser.uid, newSettings, totalXp);
      }
      setSyncStatus('synced');
      fireCelebrationConfetti();
    } catch (err) {
      console.error('Failed to complete onboarding upload:', err);
      setSyncStatus('error');
    }
  };

  // Reload all data (used after restoring backup or factory reset)
  const reloadAllData = useCallback(() => {
    setSettings(StorageService.getSettings());
    setRoutineItems(StorageService.getRoutine());
    setTaskRecords(StorageService.getTasks());
    setMonthlyGoals(StorageService.getGoals());
    setFocusSessions(StorageService.getFocusSessions());
    setBadges(StorageService.getBadges());
    setPersonalRewards(StorageService.getRewards());
    setNotifications(StorageService.getNotifications());
    setTotalXp(StorageService.getTotalXp());

    if (currentUser) {
      CloudSyncService.uploadFullLocalDataToCloud(currentUser.uid, {
        routines: StorageService.getRoutine(),
        tasks: StorageService.getTasks(),
        goals: StorageService.getGoals(),
        focusSessions: StorageService.getFocusSessions(),
        badges: StorageService.getBadges(),
        settings: StorageService.getSettings(),
        totalXp: StorageService.getTotalXp(),
      });
    }
  }, [currentUser]);

  // Check and unlock badges
  const checkBadgeUnlocks = useCallback(
    (currentRecords: TaskRecord[], currentXp: number, currentFocus: FocusSession[], goals: MonthlyGoal[]) => {
      const completedCount = currentRecords.filter((t) => t.status === 'completed').length;
      const totalFocusMinutes = currentFocus.reduce((a, b) => a + b.durationMinutes, 0);
      const { currentStreak } = calculateStreak(currentRecords);
      const completedMilestones = goals.flatMap((g) => g.milestones).filter((m) => m.completed).length;

      let newlyUnlocked = false;

      const updatedBadges = badges.map((badge) => {
        if (badge.isUnlocked) return badge;

        let shouldUnlock = false;
        let curVal = badge.currentValue;

        if (badge.id === 'first_task' && completedCount >= 1) {
          shouldUnlock = true;
          curVal = 1;
        } else if (badge.id === 'streak_3' && currentStreak >= 3) {
          shouldUnlock = true;
          curVal = currentStreak;
        } else if (badge.id === 'streak_7' && currentStreak >= 7) {
          shouldUnlock = true;
          curVal = currentStreak;
        } else if (badge.id === 'focus_5h') {
          curVal = totalFocusMinutes;
          if (totalFocusMinutes >= 300) shouldUnlock = true;
        } else if (badge.id === 'milestone_crusher') {
          curVal = completedMilestones;
          if (completedMilestones >= 5) shouldUnlock = true;
        } else if (badge.id === 'task_century') {
          curVal = completedCount;
          if (completedCount >= 50) shouldUnlock = true;
        }

        if (shouldUnlock) {
          newlyUnlocked = true;
          return {
            ...badge,
            isUnlocked: true,
            currentValue: badge.targetValue,
            unlockedAt: new Date().toISOString(),
          };
        }

        return { ...badge, currentValue: curVal };
      });

      if (newlyUnlocked) {
        setBadges(updatedBadges);
        StorageService.saveBadges(updatedBadges);
        playChime('achievement');
        fireCelebrationConfetti();

        if (currentUser) {
          CloudSyncService.saveBadges(currentUser.uid, updatedBadges);
        }
      }
    },
    [badges, currentUser]
  );

  // Toggle Task Completion Handler
  const handleToggleTaskCompletion = (taskTitle: string, routineItem?: RoutineItem) => {
    const existingIndex = taskRecords.findIndex((t) => t.title === taskTitle && t.date === todayStr);

    let updatedTasks: TaskRecord[];
    let earnedXp = 30;
    let targetTask: TaskRecord;

    if (routineItem) {
      earnedXp = routineItem.priority === 'high' ? 50 : routineItem.priority === 'medium' ? 30 : 15;
    }

    if (existingIndex >= 0) {
      const existing = taskRecords[existingIndex];
      if (existing.status === 'completed') {
        // Toggle to pending (undo)
        targetTask = { ...existing, status: 'pending', completedAt: undefined };
        updatedTasks = taskRecords.map((t, idx) => (idx === existingIndex ? targetTask : t));
        const newXp = Math.max(0, totalXp - existing.pointsAwarded);
        setTotalXp(newXp);
        StorageService.saveTotalXp(newXp);
      } else {
        // Mark completed
        targetTask = { ...existing, status: 'completed', completedAt: new Date().toISOString(), pointsAwarded: earnedXp };
        updatedTasks = taskRecords.map((t, idx) => (idx === existingIndex ? targetTask : t));
        const newXp = totalXp + earnedXp;
        setTotalXp(newXp);
        StorageService.saveTotalXp(newXp);
        playChime('complete');
        fireCelebrationConfetti();
      }
    } else {
      // New task record for today
      targetTask = {
        id: 'task_' + Date.now(),
        routineItemId: routineItem?.id,
        date: todayStr,
        title: taskTitle,
        category: routineItem?.category || 'Personal',
        startTime: routineItem?.startTime || '09:00',
        endTime: routineItem?.endTime || '10:00',
        priority: routineItem?.priority || 'medium',
        status: 'completed',
        completedAt: new Date().toISOString(),
        pointsAwarded: earnedXp,
        targetDurationMinutes: routineItem?.targetDurationMinutes,
      };
      updatedTasks = [targetTask, ...taskRecords];
      const newXp = totalXp + earnedXp;
      setTotalXp(newXp);
      StorageService.saveTotalXp(newXp);
      playChime('complete');
      fireCelebrationConfetti();
    }

    setTaskRecords(updatedTasks);
    StorageService.saveTasks(updatedTasks);
    checkBadgeUnlocks(updatedTasks, totalXp + earnedXp, focusSessions, monthlyGoals);

    // Sync to Cloud
    if (currentUser) {
      CloudSyncService.saveTaskRecord(currentUser.uid, targetTask);
      CloudSyncService.saveSettings(currentUser.uid, settings, totalXp + earnedXp);
    }
  };

  // Undo task
  const handleUndoTask = (taskId: string) => {
    const target = taskRecords.find((t) => t.id === taskId);
    if (!target) return;

    const revertedTask: TaskRecord = { ...target, status: 'pending', completedAt: undefined };
    const updatedTasks = taskRecords.map((t) => (t.id === taskId ? revertedTask : t));
    setTaskRecords(updatedTasks);
    StorageService.saveTasks(updatedTasks);

    const newXp = Math.max(0, totalXp - (target.pointsAwarded || 30));
    setTotalXp(newXp);
    StorageService.saveTotalXp(newXp);

    if (currentUser) {
      CloudSyncService.saveTaskRecord(currentUser.uid, revertedTask);
      CloudSyncService.saveSettings(currentUser.uid, settings, newXp);
    }
  };

  // Skip task
  const handleSkipTask = (taskTitle: string, routineItem?: RoutineItem) => {
    const existingIndex = taskRecords.findIndex((t) => t.title === taskTitle && t.date === todayStr);

    let skippedTask: TaskRecord;
    let updatedTasks: TaskRecord[];
    if (existingIndex >= 0) {
      skippedTask = { ...taskRecords[existingIndex], status: 'skipped', skippedAt: new Date().toISOString() };
      updatedTasks = taskRecords.map((t, idx) => (idx === existingIndex ? skippedTask : t));
    } else {
      skippedTask = {
        id: 'task_' + Date.now(),
        routineItemId: routineItem?.id,
        date: todayStr,
        title: taskTitle,
        category: routineItem?.category || 'Personal',
        startTime: routineItem?.startTime || '09:00',
        endTime: routineItem?.endTime || '10:00',
        priority: routineItem?.priority || 'medium',
        status: 'skipped',
        pointsAwarded: 0,
        skippedAt: new Date().toISOString(),
      };
      updatedTasks = [skippedTask, ...taskRecords];
    }

    setTaskRecords(updatedTasks);
    StorageService.saveTasks(updatedTasks);
    playChime('skip');

    if (currentUser) {
      CloudSyncService.saveTaskRecord(currentUser.uid, skippedTask);
    }
  };

  // Reschedule task
  const handleRescheduleTask = (taskId: string, targetDate: string) => {
    const target = taskRecords.find((t) => t.id === taskId);
    if (!target) return;

    const rescheduled: TaskRecord = { ...target, date: targetDate, status: 'pending' };
    const updated = taskRecords.map((t) => (t.id === taskId ? rescheduled : t));
    setTaskRecords(updated);
    StorageService.saveTasks(updated);

    if (currentUser) {
      CloudSyncService.saveTaskRecord(currentUser.uid, rescheduled);
    }
  };

  // Add ad-hoc task
  const handleAddTaskRecord = (task: TaskRecord) => {
    const updated = [task, ...taskRecords];
    setTaskRecords(updated);
    StorageService.saveTasks(updated);

    if (currentUser) {
      CloudSyncService.saveTaskRecord(currentUser.uid, task);
    }
  };

  // Focus on specific task
  const handleStartFocusOnTask = (taskTitle: string, category: string) => {
    setFocusTaskTitle(taskTitle);
    setFocusTaskCategory(category);
    setCurrentTab('focus');
  };

  // Focus Session Complete
  const handleRecordFocusSession = (session: FocusSession) => {
    const updated = [session, ...focusSessions];
    setFocusSessions(updated);
    StorageService.saveFocusSessions(updated);

    const newXp = totalXp + session.xpEarned;
    setTotalXp(newXp);
    StorageService.saveTotalXp(newXp);

    checkBadgeUnlocks(taskRecords, newXp, updated, monthlyGoals);

    if (currentUser) {
      CloudSyncService.saveFocusSession(currentUser.uid, session);
      CloudSyncService.saveSettings(currentUser.uid, settings, newXp);
    }
  };

  // Milestone Toggle
  const handleMilestoneToggle = (goalId: string, milestoneId: string) => {
    let targetGoal: MonthlyGoal | undefined;

    const updatedGoals = monthlyGoals.map((g) => {
      if (g.id === goalId) {
        const updatedM = g.milestones.map((m) => {
          if (m.id === milestoneId) {
            const nextState = !m.completed;
            if (nextState) {
              const newXp = totalXp + 75;
              setTotalXp(newXp);
              StorageService.saveTotalXp(newXp);
              playChime('achievement');
              fireCelebrationConfetti();
              if (currentUser) {
                CloudSyncService.saveSettings(currentUser.uid, settings, newXp);
              }
            }
            return { ...m, completed: nextState };
          }
          return m;
        });
        targetGoal = { ...g, milestones: updatedM };
        return targetGoal;
      }
      return g;
    });

    setMonthlyGoals(updatedGoals);
    StorageService.saveGoals(updatedGoals);
    checkBadgeUnlocks(taskRecords, totalXp, focusSessions, updatedGoals);

    if (currentUser && targetGoal) {
      CloudSyncService.saveMonthlyGoal(currentUser.uid, targetGoal);
    }
  };

  // Save routine items
  const handleSaveRoutine = (items: RoutineItem[]) => {
    setRoutineItems(items);
    StorageService.saveRoutine(items);

    if (currentUser) {
      items.forEach((item) => {
        CloudSyncService.saveRoutineItem(currentUser.uid, item);
      });
    }
  };

  // Save goals
  const handleSaveGoals = (goals: MonthlyGoal[]) => {
    setMonthlyGoals(goals);
    StorageService.saveGoals(goals);

    if (currentUser) {
      goals.forEach((goal) => {
        CloudSyncService.saveMonthlyGoal(currentUser.uid, goal);
      });
    }
  };

  // Redeem Reward
  const handleRedeemReward = (rewardId: string, cost: number) => {
    const updatedRewards = personalRewards.map((r) =>
      r.id === rewardId
        ? { ...r, redeemedCount: r.redeemedCount + 1, lastRedeemedAt: new Date().toISOString() }
        : r
    );
    setPersonalRewards(updatedRewards);
    StorageService.saveRewards(updatedRewards);

    const newXp = Math.max(0, totalXp - cost);
    setTotalXp(newXp);
    StorageService.saveTotalXp(newXp);

    if (currentUser) {
      CloudSyncService.saveSettings(currentUser.uid, settings, newXp);
    }
  };

  // Add custom personal reward
  const handleAddCustomReward = (reward: PersonalReward) => {
    const updated = [...personalRewards, reward];
    setPersonalRewards(updated);
    StorageService.saveRewards(updated);
  };

  // Update Settings (persists to local storage & cloud)
  const handleUpdateSettings = (newSettings: UserSettings) => {
    setSettings(newSettings);
    StorageService.saveSettings(newSettings);
    if (currentUser) {
      CloudSyncService.saveSettings(currentUser.uid, newSettings, totalXp);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Desktop Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        totalXp={totalXp}
        completedTasksToday={completedTodayCount}
        totalTasksToday={todayScheduled.length}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        {/* Top Navbar */}
        <Navbar
          currentTab={currentTab}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          totalXp={totalXp}
          streakCount={streakInfo.currentStreak}
          notifications={notifications}
          onOpenNotifications={() => setCurrentTab('notifications')}
          activeTaskCount={{ completed: completedTodayCount, total: todayScheduled.length }}
          currentUser={currentUser}
          syncStatus={syncStatus}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onNavigateTab={setCurrentTab}
          onManualSync={handleManualSync}
          onSignOut={handleSignOut}
        />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto px-4 md:px-8 py-6">
          {currentTab === 'dashboard' && (
            <DashboardView
              routineItems={routineItems}
              taskRecords={taskRecords}
              monthlyGoals={monthlyGoals}
              totalXp={totalXp}
              streakCount={streakInfo.currentStreak}
              settings={settings}
              onToggleTaskCompletion={handleToggleTaskCompletion}
              onSkipTask={handleSkipTask}
              onUndoTask={handleUndoTask}
              onNavigateTab={setCurrentTab}
              onStartFocusOnTask={handleStartFocusOnTask}
              onOpenAddRoutineModal={() => setCurrentTab('routine')}
            />
          )}

          {currentTab === 'routine' && (
            <RoutineView
              routineItems={routineItems}
              monthlyGoals={monthlyGoals}
              settings={settings}
              onSaveRoutine={handleSaveRoutine}
              onStartFocusOnTask={handleStartFocusOnTask}
            />
          )}

          {currentTab === 'calendar' && (
            <CalendarView
              routineItems={routineItems}
              taskRecords={taskRecords}
              monthlyGoals={monthlyGoals}
              settings={settings}
              onToggleTaskCompletion={handleToggleTaskCompletion}
              onOpenAddRoutineModal={() => setCurrentTab('routine')}
            />
          )}

          {currentTab === 'tasks' && (
            <TasksView
              taskRecords={taskRecords}
              routineItems={routineItems}
              settings={settings}
              onToggleTaskCompletion={handleToggleTaskCompletion}
              onSkipTask={handleSkipTask}
              onUndoTask={handleUndoTask}
              onAddTaskRecord={handleAddTaskRecord}
              onRescheduleTask={handleRescheduleTask}
            />
          )}

          {currentTab === 'roadmap' && (
            <RoadmapView
              monthlyGoals={monthlyGoals}
              onSaveGoals={handleSaveGoals}
              onMilestoneToggle={handleMilestoneToggle}
            />
          )}

          {currentTab === 'focus' && (
            <FocusTimerView
              routineItems={routineItems}
              settings={settings}
              focusSessions={focusSessions}
              onRecordSession={handleRecordFocusSession}
              preselectedTaskTitle={focusTaskTitle}
              preselectedCategory={focusTaskCategory}
            />
          )}

          {currentTab === 'achievements' && (
            <AchievementsView
              totalXp={totalXp}
              streakCount={streakInfo.currentStreak}
              bestStreak={streakInfo.bestStreak}
              badges={badges}
              personalRewards={personalRewards}
              onRedeemReward={handleRedeemReward}
              onAddCustomReward={handleAddCustomReward}
            />
          )}

          {currentTab === 'analytics' && (
            <AnalyticsView
              taskRecords={taskRecords}
              routineItems={routineItems}
              focusSessions={focusSessions}
              monthlyGoals={monthlyGoals}
              settings={settings}
              totalXp={totalXp}
            />
          )}

          {currentTab === 'notifications' && (
            <NotificationsView
              notifications={notifications}
              settings={settings}
              onUpdateNotifications={(notifs) => {
                setNotifications(notifs);
                StorageService.saveNotifications(notifs);
              }}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onReloadAllData={reloadAllData}
              currentUser={currentUser}
              syncStatus={syncStatus}
              onOpenAuthModal={() => setIsAuthModalOpen(true)}
              onManualSync={handleManualSync}
              onSignOut={handleSignOut}
            />
          )}
        </main>

        {/* Mobile Bottom Navigation */}
        <BottomNav
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          unreadNotificationsCount={notifications.filter((n) => !n.read).length}
        />

        {/* Offline Indicator */}
        <OfflineIndicator />

        {/* Google Authentication Modal */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={() => {
            setIsAuthModalOpen(false);
          }}
        />

        {/* First-Time Sign-In Onboarding Modal */}
        {currentUser && (
          <OnboardingModal
            isOpen={isOnboardingModalOpen}
            userDisplayName={currentUser.displayName || 'Scholar'}
            userEmail={currentUser.email || ''}
            existingLocalTaskCount={taskRecords.length + routineItems.length}
            onComplete={handleOnboardingComplete}
          />
        )}
      </div>
    </div>
  );
}
