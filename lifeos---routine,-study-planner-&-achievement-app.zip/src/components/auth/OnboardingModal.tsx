import React, { useState } from 'react';
import { Sparkles, Check, ArrowRight, ShieldCheck, Database, Calendar } from 'lucide-react';
import { UserSettings } from '../../types';

interface OnboardingModalProps {
  isOpen: boolean;
  userDisplayName: string;
  userEmail: string;
  existingLocalTaskCount: number;
  onComplete: (configuredSettings: Partial<UserSettings>, shouldMigrateLocalData: boolean) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  userDisplayName,
  userEmail,
  existingLocalTaskCount,
  onComplete,
}) => {
  const [displayName, setDisplayName] = useState(userDisplayName || 'Scholar');
  const [dailyHours, setDailyHours] = useState(6);
  const [weeklyHours, setWeeklyHours] = useState(35);
  const [timeFormat, setTimeFormat] = useState<'12h' | '24h'>('12h');
  const [migrateOption, setMigrateOption] = useState<'migrate' | 'clean'>('migrate');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(
      {
        displayName: displayName.trim(),
        dailyProductivityTargetHours: dailyHours,
        weeklyStudyTargetHours: weeklyHours,
        timeFormat,
      },
      migrateOption === 'migrate'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 p-6 md:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 my-8">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Welcome to LifeOS Cloud! 🚀
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Signed in as {userEmail}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              What should we call you?
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Daily Study Target
              </label>
              <input
                type="number"
                min="1"
                max="24"
                value={dailyHours}
                onChange={(e) => setDailyHours(parseInt(e.target.value, 10) || 6)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">Hours per day</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Weekly Study Target
              </label>
              <input
                type="number"
                min="1"
                max="168"
                value={weeklyHours}
                onChange={(e) => setWeeklyHours(parseInt(e.target.value, 10) || 35)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">Hours per week</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Time Display Format
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setTimeFormat('12h')}
                className={`flex-1 py-2 rounded-xl border text-xs font-semibold transition ${
                  timeFormat === '12h'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-bold'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                12-Hour (09:00 AM)
              </button>
              <button
                type="button"
                onClick={() => setTimeFormat('24h')}
                className={`flex-1 py-2 rounded-xl border text-xs font-semibold transition ${
                  timeFormat === '24h'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-bold'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                24-Hour (09:00)
              </button>
            </div>
          </div>

          {/* Local Data Migration Decision */}
          {existingLocalTaskCount > 0 && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
              <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Database className="w-4 h-4 text-indigo-500" />
                Existing Local Data Detected ({existingLocalTaskCount} tasks/routines)
              </span>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                You have existing routines and progress saved locally in this browser. How would you like to handle them?
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setMigrateOption('migrate')}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    migrateOption === 'migrate'
                      ? 'border-indigo-600 bg-white dark:bg-slate-800 ring-2 ring-indigo-500/20 font-bold text-slate-900 dark:text-white'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <p className="font-bold">Sync Existing Data</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Upload current routines & tasks to cloud</p>
                </button>

                <button
                  type="button"
                  onClick={() => setMigrateOption('clean')}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    migrateOption === 'clean'
                      ? 'border-indigo-600 bg-white dark:bg-slate-800 ring-2 ring-indigo-500/20 font-bold text-slate-900 dark:text-white'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <p className="font-bold">Start Fresh</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Initialize with clean student template</p>
                </button>
              </div>
            </div>
          )}

          <div className="pt-3">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition active:scale-98"
            >
              <span>Complete Setup & Launch Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
