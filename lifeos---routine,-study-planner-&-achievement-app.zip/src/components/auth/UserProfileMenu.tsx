import React, { useState, useRef, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  LogOut,
  LogIn,
  Settings,
  RefreshCw,
  Cloud,
  Check,
  Shield,
  WifiOff,
  User as UserIcon,
  ChevronDown,
} from 'lucide-react';
import { SyncStatus } from '../../services/cloudSync';
import { signOutFromFirebase } from '../../services/firebase';

interface UserProfileMenuProps {
  currentUser: User | null;
  syncStatus: SyncStatus;
  displayName: string;
  onOpenAuthModal: () => void;
  onNavigateTab: (tab: string) => void;
  onManualSync: () => void;
  onSignOut: () => void;
}

export const UserProfileMenu: React.FC<UserProfileMenuProps> = ({
  currentUser,
  syncStatus,
  displayName,
  onOpenAuthModal,
  onNavigateTab,
  onManualSync,
  onSignOut,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSignOutClick = async () => {
    if (confirm('Sign out from your Google account? Your local cache will remain available.')) {
      await signOutFromFirebase();
      setIsOpen(false);
      onSignOut();
    }
  };

  const getSyncBadge = () => {
    if (!currentUser) {
      return (
        <span className="flex items-center gap-1 text-[10px] text-slate-500 font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
          <Shield className="w-3 h-3 text-slate-400" />
          <span>Guest Mode</span>
        </span>
      );
    }
    if (syncStatus === 'syncing') {
      return (
        <span className="flex items-center gap-1 text-[10px] text-blue-600 dark:text-blue-400 font-semibold px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60">
          <RefreshCw className="w-3 h-3 animate-spin text-blue-500" />
          <span>Syncing...</span>
        </span>
      );
    }
    if (syncStatus === 'offline') {
      return (
        <span className="flex items-center gap-1 text-[10px] text-amber-600 dark:text-amber-400 font-semibold px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60">
          <WifiOff className="w-3 h-3 text-amber-500" />
          <span>Offline</span>
        </span>
      );
    }
    if (syncStatus === 'error') {
      return (
        <span className="flex items-center gap-1 text-[10px] text-red-600 dark:text-red-400 font-semibold px-2 py-0.5 rounded-full bg-red-50 dark:bg-red-950/60">
          <span>Sync Error</span>
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60">
        <Check className="w-3 h-3 text-emerald-500" />
        <span>Cloud Synced</span>
      </span>
    );
  };

  return (
    <div className="relative" ref={menuRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
      >
        {currentUser?.photoURL ? (
          <img
            src={currentUser.photoURL}
            alt={displayName}
            className="w-8 h-8 rounded-full ring-2 ring-indigo-500/30 object-cover shadow-sm"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white font-bold text-xs flex items-center justify-center ring-2 ring-indigo-500/20 shadow-sm">
            {displayName.charAt(0).toUpperCase()}
          </div>
        )}

        <div className="hidden lg:flex flex-col items-start text-left">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 max-w-[110px] truncate leading-tight">
            {displayName}
          </span>
          <span className="text-[10px] text-slate-400 leading-tight">
            {currentUser ? 'Google Account' : 'Guest Mode'}
          </span>
        </div>

        <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-3 z-50 animate-in fade-in zoom-in-95 space-y-3">
          {/* User Details */}
          <div className="px-2 py-1.5 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {displayName}
              </span>
              {getSyncBadge()}
            </div>
            <p className="text-[11px] text-slate-400 truncate font-mono">
              {currentUser?.email || 'Local Browser Storage'}
            </p>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-2 space-y-1">
            {currentUser ? (
              <button
                onClick={() => {
                  onManualSync();
                  setIsOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <RefreshCw className="w-3.5 h-3.5 text-indigo-500" />
                <span>Sync Cloud Data Now</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenAuthModal();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 transition"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In with Google</span>
              </button>
            )}

            <button
              onClick={() => {
                onNavigateTab('settings');
                setIsOpen(false);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <Settings className="w-3.5 h-3.5 text-slate-400" />
              <span>Account & Settings</span>
            </button>

            {currentUser && (
              <button
                onClick={handleSignOutClick}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
