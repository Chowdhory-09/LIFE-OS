import React, { useEffect, useState } from 'react';
import {
  Bell,
  Moon,
  Sun,
  Flame,
  Award,
  Clock as ClockIcon,
  CheckCircle2,
} from 'lucide-react';
import { UserSettings, AppNotification } from '../../types';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { calculateLevel } from '../../services/gamification';
import { applyTheme, getEffectiveIsDark } from '../../utils/theme';

import { User } from 'firebase/auth';
import { SyncStatus } from '../../services/cloudSync';
import { UserProfileMenu } from '../auth/UserProfileMenu';

interface NavbarProps {
  currentTab: string;
  settings: UserSettings;
  onUpdateSettings: (newSettings: UserSettings) => void;
  totalXp: number;
  streakCount: number;
  notifications: AppNotification[];
  onOpenNotifications: () => void;
  activeTaskCount: { completed: number; total: number };
  currentUser: User | null;
  syncStatus: SyncStatus;
  onOpenAuthModal: () => void;
  onNavigateTab: (tab: string) => void;
  onManualSync: () => void;
  onSignOut: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  settings,
  onUpdateSettings,
  totalXp,
  streakCount,
  notifications,
  onOpenNotifications,
  activeTaskCount,
  currentUser,
  syncStatus,
  onOpenAuthModal,
  onNavigateTab,
  onManualSync,
  onSignOut,
}) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const unreadCount = notifications.filter((n) => !n.read).length;
  const levelInfo = calculateLevel(totalXp);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const isDarkActive = getEffectiveIsDark(settings.theme);

  const toggleTheme = () => {
    const nextTheme = isDarkActive ? 'light' : 'dark';
    applyTheme(nextTheme);
    onUpdateSettings({ ...settings, theme: nextTheme });
  };

  const formattedTime = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: settings.timeFormat === '12h',
  });

  const formattedDate = currentTime.toLocaleDateString([], {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  const tabTitles: Record<string, string> = {
    dashboard: 'Dashboard Overview',
    routine: 'Daily Routine Builder',
    calendar: 'Interactive Calendar',
    tasks: 'Task Management',
    roadmap: 'Monthly Roadmap & Milestones',
    focus: 'Pomodoro Focus Timer',
    achievements: 'Achievements & Rewards',
    analytics: 'Analytics & Insights',
    notifications: 'Notification Center',
    settings: 'App Settings & Preferences',
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 px-4 md:px-6 backdrop-blur-md transition-colors">
      <div className="flex items-center gap-3">
        <div className="hidden lg:block">
          <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            {tabTitles[currentTab] || 'LifeOS'}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {formattedDate} • {formattedTime}
          </p>
        </div>
        <div className="lg:hidden flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-sm font-black text-sm">
            L
          </div>
          <span className="font-extrabold text-slate-900 dark:text-white text-base tracking-tight">
            LifeOS
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 md:gap-3">
        {/* Streak Badge */}
        <div 
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 text-xs font-semibold cursor-pointer"
          title={`${streakCount} day active streak!`}
        >
          <Flame className="w-4 h-4 fill-amber-500 text-amber-500 animate-pulse" />
          <span>{streakCount} {streakCount === 1 ? 'day' : 'days'}</span>
        </div>

        {/* Level / XP Pill */}
        <div 
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 text-xs font-semibold"
          title={`Level ${levelInfo.level} - ${levelInfo.rankTitle} (${totalXp} Total XP)`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Lvl {levelInfo.level}</span>
          <span className="text-[10px] text-indigo-400/80 hidden md:inline">({totalXp} XP)</span>
        </div>

        {/* Today's completion preview */}
        <div 
          className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-medium"
          title="Today's task completion progress"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{activeTaskCount.completed}/{activeTaskCount.total} Today</span>
        </div>

        {/* Live Clock on desktop */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-mono">
          <ClockIcon className="w-3.5 h-3.5 text-slate-400" />
          <span>{formattedTime}</span>
        </div>

        {/* PWA Install Button */}
        <PWAInstallButton compact={true} />

        {/* Notifications Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          aria-label="View notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-white dark:ring-slate-900 animate-pulse">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          aria-label="Toggle light/dark theme"
          title={`Switch to ${isDarkActive ? 'light' : 'dark'} mode`}
        >
          {isDarkActive ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-indigo-600" />
          )}
        </button>

        {/* Google Sign In / User Profile Dropdown */}
        <div className="flex items-center gap-2 pl-1 border-l border-slate-200 dark:border-slate-800">
          {!currentUser && (
            <button
              onClick={onOpenAuthModal}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold text-xs shadow-sm hover:from-indigo-500 hover:to-violet-500 transition active:scale-95"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path fill="#ffffff" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14.5v-9l6 4.5-6 4.5z"/>
              </svg>
              <span>Sign In</span>
            </button>
          )}

          <UserProfileMenu
            currentUser={currentUser}
            syncStatus={syncStatus}
            displayName={settings.displayName}
            onOpenAuthModal={onOpenAuthModal}
            onNavigateTab={onNavigateTab}
            onManualSync={onManualSync}
            onSignOut={onSignOut}
          />
        </div>
      </div>
    </header>
  );
};
