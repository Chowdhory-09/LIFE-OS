import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import { User } from 'firebase/auth';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  AchievementBadge,
  FocusSession,
  MonthlyGoal,
  PersonalReward,
  RoutineItem,
  TaskRecord,
  UserSettings,
} from '../types';

export type SyncStatus = 'synced' | 'syncing' | 'offline' | 'error' | 'local_only';

export class CloudSyncService {
  /**
   * Save or update user profile document
   */
  static async syncUserProfile(user: User): Promise<boolean> {
    const path = `users/${user.uid}/profile/main`;
    try {
      const profileRef = doc(db, 'users', user.uid, 'profile', 'main');
      const snap = await getDoc(profileRef);

      const profileData = {
        uid: user.uid,
        displayName: user.displayName || 'LifeOS User',
        email: user.email || '',
        photoURL: user.photoURL || '',
        updatedAt: new Date().toISOString(),
        ...(!snap.exists() ? { createdAt: new Date().toISOString() } : {}),
      };

      await setDoc(profileRef, profileData, { merge: true });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      return false;
    }
  }

  /**
   * Fetch all cloud user data at once
   */
  static async fetchAllUserData(userId: string): Promise<{
    routines: RoutineItem[];
    tasks: TaskRecord[];
    goals: MonthlyGoal[];
    focusSessions: FocusSession[];
    badges: AchievementBadge[];
    settings: UserSettings | null;
    isNewAccount: boolean;
  }> {
    try {
      // 1. Settings
      const settingsRef = doc(db, 'users', userId, 'settings', 'main');
      const settingsSnap = await getDoc(settingsRef);
      const settings = settingsSnap.exists() ? (settingsSnap.data() as UserSettings) : null;

      // 2. Routines
      const routinesSnap = await getDocs(collection(db, 'users', userId, 'routines'));
      const routines = routinesSnap.docs.map((d) => d.data() as RoutineItem);

      // 3. Tasks
      const tasksSnap = await getDocs(collection(db, 'users', userId, 'tasks'));
      const tasks = tasksSnap.docs.map((d) => d.data() as TaskRecord);

      // 4. Goals
      const goalsSnap = await getDocs(collection(db, 'users', userId, 'monthlyGoals'));
      const goals = goalsSnap.docs.map((d) => d.data() as MonthlyGoal);

      // 5. Focus Sessions
      const focusSnap = await getDocs(collection(db, 'users', userId, 'focusSessions'));
      const focusSessions = focusSnap.docs.map((d) => d.data() as FocusSession);

      // 6. Badges
      const badgesSnap = await getDocs(collection(db, 'users', userId, 'achievements'));
      const badges = badgesSnap.docs.map((d) => d.data() as AchievementBadge);

      const isNewAccount =
        !settingsSnap.exists() &&
        routines.length === 0 &&
        tasks.length === 0 &&
        goals.length === 0;

      return {
        routines,
        tasks,
        goals,
        focusSessions,
        badges,
        settings,
        isNewAccount,
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${userId}`);
      throw err;
    }
  }

  /**
   * Migrate and upload existing local data to Cloud Firestore in a batch
   */
  static async uploadFullLocalDataToCloud(
    userId: string,
    data: {
      routines: RoutineItem[];
      tasks: TaskRecord[];
      goals: MonthlyGoal[];
      focusSessions: FocusSession[];
      badges: AchievementBadge[];
      settings: UserSettings;
      totalXp: number;
    }
  ): Promise<boolean> {
    try {
      const batch = writeBatch(db);

      // 1. Settings doc
      const settingsRef = doc(db, 'users', userId, 'settings', 'main');
      batch.set(settingsRef, { ...data.settings, totalXp: data.totalXp });

      // 2. Routines
      data.routines.forEach((r) => {
        const ref = doc(db, 'users', userId, 'routines', r.id);
        batch.set(ref, r);
      });

      // 3. Tasks (up to 50 most recent to fit inside atomic batch)
      data.tasks.slice(0, 50).forEach((t) => {
        const ref = doc(db, 'users', userId, 'tasks', t.id);
        batch.set(ref, t);
      });

      // 4. Goals
      data.goals.forEach((g) => {
        const ref = doc(db, 'users', userId, 'monthlyGoals', g.id);
        batch.set(ref, g);
      });

      // 5. Focus sessions
      data.focusSessions.slice(0, 50).forEach((s) => {
        const ref = doc(db, 'users', userId, 'focusSessions', s.id);
        batch.set(ref, s);
      });

      // 6. Badges
      data.badges.forEach((b) => {
        const ref = doc(db, 'users', userId, 'achievements', b.id);
        batch.set(ref, b);
      });

      await batch.commit();
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${userId}`);
      return false;
    }
  }

  /**
   * Save individual item changes to Cloud Firestore
   */
  static async saveRoutineItem(userId: string, item: RoutineItem): Promise<void> {
    const path = `users/${userId}/routines/${item.id}`;
    try {
      const ref = doc(db, 'users', userId, 'routines', item.id);
      await setDoc(ref, item);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  static async deleteRoutineItem(userId: string, itemId: string): Promise<void> {
    const path = `users/${userId}/routines/${itemId}`;
    try {
      const ref = doc(db, 'users', userId, 'routines', itemId);
      await deleteDoc(ref);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  }

  static async saveTaskRecord(userId: string, task: TaskRecord): Promise<void> {
    const path = `users/${userId}/tasks/${task.id}`;
    try {
      const ref = doc(db, 'users', userId, 'tasks', task.id);
      await setDoc(ref, task);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  static async saveMonthlyGoal(userId: string, goal: MonthlyGoal): Promise<void> {
    const path = `users/${userId}/monthlyGoals/${goal.id}`;
    try {
      const ref = doc(db, 'users', userId, 'monthlyGoals', goal.id);
      await setDoc(ref, goal);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  static async deleteMonthlyGoal(userId: string, goalId: string): Promise<void> {
    const path = `users/${userId}/monthlyGoals/${goalId}`;
    try {
      const ref = doc(db, 'users', userId, 'monthlyGoals', goalId);
      await deleteDoc(ref);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  }

  static async saveFocusSession(userId: string, session: FocusSession): Promise<void> {
    const path = `users/${userId}/focusSessions/${session.id}`;
    try {
      const ref = doc(db, 'users', userId, 'focusSessions', session.id);
      await setDoc(ref, session);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  static async saveBadge(userId: string, badge: AchievementBadge): Promise<void> {
    const path = `users/${userId}/achievements/${badge.id}`;
    try {
      const ref = doc(db, 'users', userId, 'achievements', badge.id);
      await setDoc(ref, badge, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  static async saveBadges(userId: string, badges: AchievementBadge[]): Promise<void> {
    try {
      const batch = writeBatch(db);
      badges.forEach((b) => {
        const ref = doc(db, 'users', userId, 'achievements', b.id);
        batch.set(ref, b, { merge: true });
      });
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${userId}/achievements`);
    }
  }

  static async saveSettings(userId: string, settings: UserSettings, totalXp: number): Promise<void> {
    const path = `users/${userId}/settings/main`;
    try {
      const ref = doc(db, 'users', userId, 'settings', 'main');
      await setDoc(ref, { ...settings, totalXp }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }
}

