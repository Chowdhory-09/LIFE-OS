import confetti from 'canvas-confetti';
import { AchievementBadge, TaskRecord, UserSettings } from '../types';
import { playChime } from './audio';

export interface LevelInfo {
  level: number;
  rankTitle: string;
  currentXp: number;
  xpForCurrentLevel: number;
  xpForNextLevel: number;
  progressPercent: number;
}

export function calculateLevel(totalXp: number): LevelInfo {
  if (totalXp < 0) totalXp = 0;
  const level = Math.floor(Math.sqrt(totalXp / 100)) + 1;
  const xpForCurrentLevel = Math.pow(level - 1, 2) * 100;
  const xpForNextLevel = Math.pow(level, 2) * 100;

  const xpEarnedInLevel = totalXp - xpForCurrentLevel;
  const xpNeededForLevel = xpForNextLevel - xpForCurrentLevel;
  const progressPercent = Math.min(100, Math.max(0, Math.round((xpEarnedInLevel / xpNeededForLevel) * 100)));

  let rankTitle = 'Novice Scholar';
  if (level >= 12) rankTitle = 'Grandmaster of Routine';
  else if (level >= 8) rankTitle = 'Productivity Master';
  else if (level >= 5) rankTitle = 'Routine Specialist';
  else if (level >= 3) rankTitle = 'Focused Apprentice';

  return {
    level,
    rankTitle,
    currentXp: totalXp,
    xpForCurrentLevel,
    xpForNextLevel,
    progressPercent,
  };
}

export function fireCelebrationConfetti(): void {
  try {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#6366f1', '#a855f7', '#38bdf8', '#fbbf24', '#10b981'],
    });
  } catch (e) {
    console.debug('Confetti suppressed:', e);
  }
}

export function calculateStreak(taskRecords: TaskRecord[]): {
  currentStreak: number;
  bestStreak: number;
  activeDates: Set<string>;
} {
  const completedRecords = taskRecords.filter((t) => t.status === 'completed');
  const activeDates = new Set<string>(completedRecords.map((t) => t.date));

  const sortedDates = Array.from(activeDates).sort();
  if (sortedDates.length === 0) {
    return { currentStreak: 0, bestStreak: 0, activeDates };
  }

  // Calculate current streak backward from today or yesterday
  const now = new Date();
  const todayStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
  
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = `${yesterday.getFullYear()}-${(yesterday.getMonth() + 1).toString().padStart(2, '0')}-${yesterday.getDate().toString().padStart(2, '0')}`;

  let currentStreak = 0;
  let checkDate = activeDates.has(todayStr) ? new Date(now) : activeDates.has(yesterdayStr) ? new Date(yesterday) : null;

  if (checkDate) {
    while (true) {
      const dateStr = `${checkDate.getFullYear()}-${(checkDate.getMonth() + 1).toString().padStart(2, '0')}-${checkDate.getDate().toString().padStart(2, '0')}`;
      if (activeDates.has(dateStr)) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  // Calculate longest historical streak
  let bestStreak = 0;
  let running = 0;
  let lastTime: number | null = null;

  for (const dateStr of sortedDates) {
    const curTime = new Date(dateStr + 'T00:00:00').getTime();
    if (lastTime === null) {
      running = 1;
    } else {
      const diffDays = Math.round((curTime - lastTime) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        running++;
      } else if (diffDays > 1) {
        running = 1;
      }
    }
    lastTime = curTime;
    if (running > bestStreak) {
      bestStreak = running;
    }
  }

  return { currentStreak, bestStreak, activeDates };
}

export const INITIAL_ACHIEVEMENT_BADGES: AchievementBadge[] = [
  {
    id: 'first_task',
    title: 'First Step',
    description: 'Complete your very first routine task or study session.',
    category: 'daily',
    icon: 'CheckCircle2',
    xpReward: 50,
    targetValue: 1,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'daily_perfect',
    title: 'Flawless Day',
    description: 'Complete 100% of all scheduled activities in a single day.',
    category: 'daily',
    icon: 'Zap',
    xpReward: 150,
    targetValue: 1,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'streak_3',
    title: 'Consistency Spark',
    description: 'Maintain a daily productivity streak for 3 consecutive days.',
    category: 'streak',
    icon: 'Flame',
    xpReward: 100,
    targetValue: 3,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'streak_7',
    title: 'Unstoppable Momentum',
    description: 'Reach a solid 7-day routine and study streak.',
    category: 'streak',
    icon: 'Crown',
    xpReward: 250,
    targetValue: 7,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'focus_5h',
    title: 'Deep Work Champion',
    description: 'Accumulate at least 5 hours (300 minutes) of completed Focus Timer sessions.',
    category: 'focus',
    icon: 'Clock',
    xpReward: 150,
    targetValue: 300,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'cp_solver',
    title: 'Algorithm Knight',
    description: 'Complete 15 Competitive Programming study blocks.',
    category: 'monthly',
    icon: 'Code2',
    xpReward: 200,
    targetValue: 15,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'ielts_master',
    title: 'Language Scholar',
    description: 'Log 10 IELTS preparation tasks or speaking sessions.',
    category: 'monthly',
    icon: 'BookOpen',
    xpReward: 200,
    targetValue: 10,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'milestone_crusher',
    title: 'Roadmap Conqueror',
    description: 'Check off 5 weekly roadmap milestones.',
    category: 'monthly',
    icon: 'Target',
    xpReward: 250,
    targetValue: 5,
    currentValue: 0,
    isUnlocked: false,
  },
  {
    id: 'task_century',
    title: 'Task Centurion',
    description: 'Successfully complete 50 tasks across all categories.',
    category: 'special',
    icon: 'Award',
    xpReward: 500,
    targetValue: 50,
    currentValue: 0,
    isUnlocked: false,
  },
];
