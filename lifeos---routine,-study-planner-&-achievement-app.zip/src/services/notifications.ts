import { AppNotification, RoutineItem, UserSettings } from '../types';
import { calculateDurationMinutes, formatTimeDisplay, getTodayDateString, timeToMinutes } from '../utils/schedule';
import { playChime } from './audio';

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return 'denied';
  }
}

export function getNotificationPermissionState(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

export function showBrowserNotification(title: string, options?: NotificationOptions): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        icon: '/pwa-192x192.png',
        badge: '/favicon.ico',
        ...options,
      });
    } catch {
      // In some mobile browsers, notification must be dispatched via ServiceWorkerRegistration
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.ready.then((reg) => {
          reg.showNotification(title, {
            icon: '/pwa-192x192.png',
            badge: '/favicon.ico',
            ...options,
          });
        });
      }
    }
  }
}

// Track sent alerts in current session to prevent spamming
const sentAlertKeys = new Set<string>();

export function checkAndTriggerReminders(
  routineItems: RoutineItem[],
  settings: UserSettings,
  onNewNotification: (notification: AppNotification) => void
): void {
  if (!settings.notificationsEnabled) return;

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const todayStr = getTodayDateString();
  const dayIndex = now.getDay();

  const activeItems = routineItems.filter((item) => {
    if (!item.reminderEnabled) return false;
    if (!item.isRecurring && item.specificDate) {
      return item.specificDate === todayStr;
    }
    return item.daysOfWeek.includes(dayIndex);
  });

  for (const item of activeItems) {
    const startM = timeToMinutes(item.startTime);
    const reminderLead = item.reminderMinutes || settings.defaultReminderMinutes || 10;
    const targetAlertTime = startM - reminderLead;

    // Trigger window: within current minute
    if (currentMinutes === targetAlertTime || (currentMinutes > targetAlertTime && currentMinutes <= targetAlertTime + 2)) {
      const alertKey = `${todayStr}_${item.id}_${item.startTime}_${reminderLead}`;
      if (!sentAlertKeys.has(alertKey)) {
        sentAlertKeys.add(alertKey);

        const duration = calculateDurationMinutes(item.startTime, item.endTime);
        const formattedTime = formatTimeDisplay(item.startTime, settings.timeFormat);
        const title = `Reminder: ${item.title} starts in ${reminderLead}m`;
        const message = `Scheduled at ${formattedTime} (${duration} mins) • ${item.category}`;

        // 1. Play chime if sound enabled
        if (settings.soundAlerts) {
          playChime('complete');
        }

        // 2. Browser notification
        showBrowserNotification(title, {
          body: message,
          tag: alertKey,
        });

        // 3. In-App Notification Center item
        const notif: AppNotification = {
          id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          title,
          message,
          timestamp: new Date().toISOString(),
          type: 'reminder',
          read: false,
          linkTab: 'routine',
        };
        onNewNotification(notif);
      }
    }
  }
}
