import {
  AchievementBadge,
  AppNotification,
  FocusSession,
  MonthlyGoal,
  PersonalReward,
  RoutineItem,
  TaskRecord,
  UserSettings,
} from '../types';
import { getCurrentMonthString, getTodayDateString } from '../utils/schedule';
import { INITIAL_ACHIEVEMENT_BADGES } from './gamification';

const STORAGE_KEYS = {
  ROUTINE: 'lifeos_routine_items_v2',
  TASKS: 'lifeos_task_records_v2',
  GOALS: 'lifeos_monthly_goals_v2',
  FOCUS: 'lifeos_focus_sessions_v2',
  BADGES: 'lifeos_achievement_badges_v2',
  REWARDS: 'lifeos_personal_rewards_v2',
  SETTINGS: 'lifeos_user_settings_v2',
  NOTIFICATIONS: 'lifeos_notifications_v2',
  TOTAL_XP: 'lifeos_total_xp_v2',
  SYNC_CONFIG: 'lifeos_cloud_sync_config_v2',
};

export const DEFAULT_SETTINGS: UserSettings = {
  displayName: 'Alex Chen',
  timezone: typeof Intl !== 'undefined' ? Intl.DateTimeFormat().resolvedOptions().timeZone : 'UTC',
  timeFormat: '12h',
  weekStartsOn: 1, // Monday
  theme: 'dark',
  notificationsEnabled: true,
  defaultReminderMinutes: 10,
  soundAlerts: true,
  defaultFocusDuration: 25,
  defaultShortBreak: 5,
  defaultLongBreak: 15,
  dailyProductivityTargetHours: 6,
  weeklyStudyTargetHours: 35,
  autoDetectConflicts: true,
};

export const DEFAULT_ROUTINE_ITEMS: RoutineItem[] = [
  {
    id: 'r_morning_cardio',
    title: 'Morning Routine & Cardio',
    category: 'Exercise',
    startTime: '06:30',
    endTime: '07:15',
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    isRecurring: true,
    description: 'Hydrate, mobility stretches, and 20 min morning jog.',
    priority: 'medium',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 45,
    orderIndex: 0,
  },
  {
    id: 'r_ielts_morning',
    title: 'IELTS Academic Reading & Vocab',
    category: 'IELTS',
    startTime: '07:30',
    endTime: '08:45',
    daysOfWeek: [1, 2, 3, 4, 5],
    isRecurring: true,
    description: 'Cambridge practice passage + 15 new academic vocabulary terms.',
    priority: 'high',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 75,
    linkedGoalId: 'goal_ielts',
    orderIndex: 1,
  },
  {
    id: 'r_uni_lecture',
    title: 'University Lectures & Lab Coursework',
    category: 'University',
    startTime: '09:00',
    endTime: '12:00',
    daysOfWeek: [1, 2, 3, 4, 5],
    isRecurring: true,
    description: 'Advanced Data Structures lecture and Operating Systems lab.',
    priority: 'high',
    reminderMinutes: 15,
    reminderEnabled: true,
    targetDurationMinutes: 180,
    linkedGoalId: 'goal_uni',
    orderIndex: 2,
  },
  {
    id: 'r_lunch_break',
    title: 'Healthy Lunch & Power Break',
    category: 'Break',
    startTime: '12:00',
    endTime: '13:00',
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    isRecurring: true,
    description: 'Nutritious meal and offline relaxation to reset mental focus.',
    priority: 'low',
    reminderMinutes: 5,
    reminderEnabled: false,
    targetDurationMinutes: 60,
    orderIndex: 3,
  },
  {
    id: 'r_webdev_core',
    title: 'Full-Stack Web Dev: Architecture & Code',
    category: 'Web Development',
    startTime: '13:30',
    endTime: '15:30',
    daysOfWeek: [1, 2, 3, 4, 5],
    isRecurring: true,
    description: 'Building microservices architecture, REST APIs, and responsive React components.',
    priority: 'high',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 120,
    linkedGoalId: 'goal_webdev',
    orderIndex: 4,
  },
  {
    id: 'r_cp_practice',
    title: 'Competitive Programming: DP & Graph Problems',
    category: 'Competitive Programming',
    startTime: '16:00',
    endTime: '18:00',
    daysOfWeek: [1, 2, 3, 4, 5],
    isRecurring: true,
    description: 'Codeforces Div 2 problem C/D practice, Dijkstra/BFS review, and editorial notes.',
    priority: 'high',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 120,
    linkedGoalId: 'goal_cp',
    orderIndex: 5,
  },
  {
    id: 'r_gym_evening',
    title: 'Strength Training & Core Workout',
    category: 'Exercise',
    startTime: '18:30',
    endTime: '19:45',
    daysOfWeek: [1, 3, 5],
    isRecurring: true,
    description: 'Resistance training session and cooldown stretching.',
    priority: 'medium',
    reminderMinutes: 15,
    reminderEnabled: true,
    targetDurationMinutes: 75,
    orderIndex: 6,
  },
  {
    id: 'r_daily_review',
    title: 'Daily Review & Tomorrow Planning',
    category: 'Personal',
    startTime: '20:15',
    endTime: '20:45',
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    isRecurring: true,
    description: 'Review completed items, verify streak, and adjust tomorrow timetable.',
    priority: 'medium',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 30,
    orderIndex: 7,
  },
  {
    id: 'r_ielts_speaking',
    title: 'IELTS Speaking & Podcast Audio Drill',
    category: 'IELTS',
    startTime: '21:00',
    endTime: '21:45',
    daysOfWeek: [2, 4, 6],
    isRecurring: true,
    description: 'Record Part 2 cue-card topic and analyze fluency, collocations, and pronunciation.',
    priority: 'medium',
    reminderMinutes: 5,
    reminderEnabled: true,
    targetDurationMinutes: 45,
    linkedGoalId: 'goal_ielts',
    orderIndex: 8,
  },
  {
    id: 'r_weekend_contest',
    title: 'Competitive Programming Virtual Contest',
    category: 'Competitive Programming',
    startTime: '10:00',
    endTime: '12:30',
    daysOfWeek: [6], // Saturday
    isRecurring: true,
    description: '2.5 hour timed contest simulation under strict rating test conditions.',
    priority: 'high',
    reminderMinutes: 15,
    reminderEnabled: true,
    targetDurationMinutes: 150,
    linkedGoalId: 'goal_cp',
    orderIndex: 9,
  },
  {
    id: 'r_weekend_opensource',
    title: 'Open Source Contribution & Deployment',
    category: 'Web Development',
    startTime: '14:00',
    endTime: '17:00',
    daysOfWeek: [0], // Sunday
    isRecurring: true,
    description: 'Review PRs, optimize Docker pipelines, and write unit tests.',
    priority: 'medium',
    reminderMinutes: 10,
    reminderEnabled: true,
    targetDurationMinutes: 180,
    linkedGoalId: 'goal_webdev',
    orderIndex: 10,
  },
  {
    id: 'r_sleep_recovery',
    title: 'Sleep & Full Body Recovery',
    category: 'Sleep',
    startTime: '23:00',
    endTime: '06:30',
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    isRecurring: true,
    description: '7.5 hours high-quality restorative sleep in dark room.',
    priority: 'low',
    reminderMinutes: 15,
    reminderEnabled: false,
    targetDurationMinutes: 450,
    orderIndex: 11,
  },
];

export const DEFAULT_MONTHLY_GOALS: MonthlyGoal[] = [
  {
    id: 'goal_cp',
    month: getCurrentMonthString(),
    title: 'Solve 60 Competitive Programming Problems',
    category: 'Competitive Programming',
    description: 'Master medium-hard Dynamic Programming, Segment Trees, and Graph algorithms on Codeforces and LeetCode.',
    targetCompletionDate: `${getCurrentMonthString()}-28`,
    priority: 'high',
    estimatedHours: 35,
    completedHours: 24,
    targetMetric: {
      current: 42,
      target: 60,
      unit: 'problems',
    },
    milestones: [
      { id: 'm_cp_1', title: '15 Dynamic Programming Problems', weekNumber: 1, completed: true, dueDate: `${getCurrentMonthString()}-07` },
      { id: 'm_cp_2', title: '15 Graph & Shortest Path Problems', weekNumber: 2, completed: true, dueDate: `${getCurrentMonthString()}-14` },
      { id: 'm_cp_3', title: '15 Trees & Segment Tree Queries', weekNumber: 3, completed: false, dueDate: `${getCurrentMonthString()}-21` },
      { id: 'm_cp_4', title: '15 Greedy & Math Problems + Contest', weekNumber: 4, completed: false, dueDate: `${getCurrentMonthString()}-28` },
    ],
    isArchived: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'goal_webdev',
    month: getCurrentMonthString(),
    title: 'Deploy Full-Stack Production SaaS App',
    category: 'Web Development',
    description: 'Design, develop, test, and ship complete full-stack web application with responsive UI, cloud database, and CI/CD.',
    targetCompletionDate: `${getCurrentMonthString()}-30`,
    priority: 'high',
    estimatedHours: 40,
    completedHours: 28,
    targetMetric: {
      current: 3,
      target: 4,
      unit: 'sprints',
    },
    milestones: [
      { id: 'm_wd_1', title: 'Database schema, authentication, & API routes', weekNumber: 1, completed: true, dueDate: `${getCurrentMonthString()}-07` },
      { id: 'm_wd_2', title: 'Interactive frontend with Tailwind & Dark mode', weekNumber: 2, completed: true, dueDate: `${getCurrentMonthString()}-14` },
      { id: 'm_wd_3', title: 'Real-time sync, PWA service worker, & offline cache', weekNumber: 3, completed: true, dueDate: `${getCurrentMonthString()}-21` },
      { id: 'm_wd_4', title: 'End-to-end testing, SEO audit, and production release', weekNumber: 4, completed: false, dueDate: `${getCurrentMonthString()}-28` },
    ],
    isArchived: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'goal_ielts',
    month: getCurrentMonthString(),
    title: 'IELTS Academic: Band 8.0 Target Prep',
    category: 'IELTS',
    description: 'Complete 30 hours of intensive study covering Reading passages, Academic Writing Task 2 essays, and daily Speaking recordings.',
    targetCompletionDate: `${getCurrentMonthString()}-26`,
    priority: 'medium',
    estimatedHours: 30,
    completedHours: 21,
    targetMetric: {
      current: 21,
      target: 30,
      unit: 'hours',
    },
    milestones: [
      { id: 'm_il_1', title: 'Complete 6 Cambridge Reading mock exams', weekNumber: 1, completed: true, dueDate: `${getCurrentMonthString()}-07` },
      { id: 'm_il_2', title: 'Write 8 Task 2 essays with lexical resource review', weekNumber: 2, completed: true, dueDate: `${getCurrentMonthString()}-14` },
      { id: 'm_il_3', title: 'Daily 20m Speaking simulation recordings', weekNumber: 3, completed: false, dueDate: `${getCurrentMonthString()}-21` },
      { id: 'm_il_4', title: 'Full timed 3-hour mock test under exam conditions', weekNumber: 4, completed: false, dueDate: `${getCurrentMonthString()}-26` },
    ],
    isArchived: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'goal_uni',
    month: getCurrentMonthString(),
    title: 'Maintain 3.8+ GPA in University Semester',
    category: 'University',
    description: 'Complete all assignments 48 hours prior to deadline and achieve top marks on lab projects.',
    targetCompletionDate: `${getCurrentMonthString()}-31`,
    priority: 'high',
    estimatedHours: 35,
    completedHours: 25,
    targetMetric: {
      current: 4,
      target: 5,
      unit: 'assignments',
    },
    milestones: [
      { id: 'm_un_1', title: 'Submit Algorithms & Complexity Assignment 1', weekNumber: 1, completed: true, dueDate: `${getCurrentMonthString()}-06` },
      { id: 'm_un_2', title: 'Complete OS Multi-threading Lab 2', weekNumber: 2, completed: true, dueDate: `${getCurrentMonthString()}-13` },
      { id: 'm_un_3', title: 'Database Distributed Transactions Project', weekNumber: 3, completed: false, dueDate: `${getCurrentMonthString()}-20` },
      { id: 'm_un_4', title: 'Final Term Paper & Presentation Deck', weekNumber: 4, completed: false, dueDate: `${getCurrentMonthString()}-29` },
    ],
    isArchived: false,
    createdAt: new Date().toISOString(),
  },
];

export const DEFAULT_PERSONAL_REWARDS: PersonalReward[] = [
  { id: 'rew_1', title: '1 Hour Guilt-Free Video Game Session', costXp: 150, icon: 'Gamepad2', redeemedCount: 4 },
  { id: 'rew_2', title: 'Specialty Espresso / Boba Tea Treat', costXp: 200, icon: 'Coffee', redeemedCount: 3 },
  { id: 'rew_3', title: 'Weekend Movie Night & Gourmet Snack', costXp: 350, icon: 'Film', redeemedCount: 2 },
  { id: 'rew_4', title: 'Tech Gadget / Book Purchase Milestone', costXp: 800, icon: 'ShoppingBag', redeemedCount: 1 },
];

// Helper to seed initial completed tasks for today so dashboard has lively data immediately
export function generateInitialTasks(routineItems: RoutineItem[]): TaskRecord[] {
  const today = getTodayDateString();
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = `${yesterdayDate.getFullYear()}-${(yesterdayDate.getMonth() + 1).toString().padStart(2, '0')}-${yesterdayDate.getDate().toString().padStart(2, '0')}`;

  const initialTasks: TaskRecord[] = [];

  // Yesterday completed tasks (creates a streak!)
  initialTasks.push(
    {
      id: 'task_y1',
      date: yesterday,
      title: 'Morning Routine & Cardio',
      category: 'Exercise',
      startTime: '06:30',
      endTime: '07:15',
      priority: 'medium',
      status: 'completed',
      completedAt: `${yesterday}T07:14:00Z`,
      pointsAwarded: 30,
      targetDurationMinutes: 45,
    },
    {
      id: 'task_y2',
      date: yesterday,
      title: 'IELTS Academic Reading & Vocab',
      category: 'IELTS',
      startTime: '07:30',
      endTime: '08:45',
      priority: 'high',
      status: 'completed',
      completedAt: `${yesterday}T08:40:00Z`,
      pointsAwarded: 50,
      targetDurationMinutes: 75,
    },
    {
      id: 'task_y3',
      date: yesterday,
      title: 'University Lectures & Lab Coursework',
      category: 'University',
      startTime: '09:00',
      endTime: '12:00',
      priority: 'high',
      status: 'completed',
      completedAt: `${yesterday}T11:58:00Z`,
      pointsAwarded: 50,
      targetDurationMinutes: 180,
    },
    {
      id: 'task_y4',
      date: yesterday,
      title: 'Competitive Programming: DP & Graph Problems',
      category: 'Competitive Programming',
      startTime: '16:00',
      endTime: '18:00',
      priority: 'high',
      status: 'completed',
      completedAt: `${yesterday}T17:55:00Z`,
      pointsAwarded: 50,
      targetDurationMinutes: 120,
    }
  );

  // Today initial tasks
  initialTasks.push(
    {
      id: 'task_t1',
      routineItemId: 'r_morning_cardio',
      date: today,
      title: 'Morning Routine & Cardio',
      category: 'Exercise',
      startTime: '06:30',
      endTime: '07:15',
      priority: 'medium',
      status: 'completed',
      completedAt: `${today}T07:10:00Z`,
      pointsAwarded: 30,
      targetDurationMinutes: 45,
    },
    {
      id: 'task_t2',
      routineItemId: 'r_ielts_morning',
      date: today,
      title: 'IELTS Academic Reading & Vocab',
      category: 'IELTS',
      startTime: '07:30',
      endTime: '08:45',
      priority: 'high',
      status: 'completed',
      completedAt: `${today}T08:42:00Z`,
      pointsAwarded: 50,
      targetDurationMinutes: 75,
    },
    {
      id: 'task_t3',
      routineItemId: 'r_uni_lecture',
      date: today,
      title: 'University Lectures & Lab Coursework',
      category: 'University',
      startTime: '09:00',
      endTime: '12:00',
      priority: 'high',
      status: 'completed',
      completedAt: `${today}T11:50:00Z`,
      pointsAwarded: 50,
      targetDurationMinutes: 180,
    },
    {
      id: 'task_t4',
      routineItemId: 'r_lunch_break',
      date: today,
      title: 'Healthy Lunch & Power Break',
      category: 'Break',
      startTime: '12:00',
      endTime: '13:00',
      priority: 'low',
      status: 'completed',
      completedAt: `${today}T12:55:00Z`,
      pointsAwarded: 15,
      targetDurationMinutes: 60,
    },
    {
      id: 'task_t5',
      routineItemId: 'r_webdev_core',
      date: today,
      title: 'Full-Stack Web Dev: Architecture & Code',
      category: 'Web Development',
      startTime: '13:30',
      endTime: '15:30',
      priority: 'high',
      status: 'pending',
      pointsAwarded: 50,
      targetDurationMinutes: 120,
    },
    {
      id: 'task_t6',
      routineItemId: 'r_cp_practice',
      date: today,
      title: 'Competitive Programming: DP & Graph Problems',
      category: 'Competitive Programming',
      startTime: '16:00',
      endTime: '18:00',
      priority: 'high',
      status: 'pending',
      pointsAwarded: 50,
      targetDurationMinutes: 120,
    },
    {
      id: 'task_t7',
      routineItemId: 'r_daily_review',
      date: today,
      title: 'Daily Review & Tomorrow Planning',
      category: 'Personal',
      startTime: '20:15',
      endTime: '20:45',
      priority: 'medium',
      status: 'pending',
      pointsAwarded: 30,
      targetDurationMinutes: 30,
    }
  );

  return initialTasks;
}

export class StorageService {
  static getSettings(): UserSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (data) return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  }

  static saveSettings(settings: UserSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings:', e);
    }
  }

  static getRoutine(): RoutineItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ROUTINE);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    this.saveRoutine(DEFAULT_ROUTINE_ITEMS);
    return DEFAULT_ROUTINE_ITEMS;
  }

  static saveRoutine(items: RoutineItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ROUTINE, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save routine:', e);
    }
  }

  static getTasks(): TaskRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TASKS);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    const initial = generateInitialTasks(DEFAULT_ROUTINE_ITEMS);
    this.saveTasks(initial);
    return initial;
  }

  static saveTasks(tasks: TaskRecord[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch (e) {
      console.error('Failed to save tasks:', e);
    }
  }

  static getGoals(): MonthlyGoal[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.GOALS);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    this.saveGoals(DEFAULT_MONTHLY_GOALS);
    return DEFAULT_MONTHLY_GOALS;
  }

  static saveGoals(goals: MonthlyGoal[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
    } catch (e) {
      console.error('Failed to save goals:', e);
    }
  }

  static getFocusSessions(): FocusSession[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.FOCUS);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    // Initial sample focus sessions
    const today = getTodayDateString();
    const initial: FocusSession[] = [
      {
        id: 'f_init_1',
        taskTitle: 'IELTS Academic Reading',
        category: 'IELTS',
        durationMinutes: 50,
        completedAt: `${today}T08:30:00Z`,
        type: 'pomodoro',
        xpEarned: 50,
      },
      {
        id: 'f_init_2',
        taskTitle: 'University OS Lab',
        category: 'University',
        durationMinutes: 60,
        completedAt: `${today}T11:00:00Z`,
        type: 'pomodoro',
        xpEarned: 60,
      },
    ];
    this.saveFocusSessions(initial);
    return initial;
  }

  static saveFocusSessions(sessions: FocusSession[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.FOCUS, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save focus sessions:', e);
    }
  }

  static getBadges(): AchievementBadge[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BADGES);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    // Unlock first task badge by default based on seed
    const badges = INITIAL_ACHIEVEMENT_BADGES.map((b) => {
      if (b.id === 'first_task') {
        return { ...b, currentValue: 1, isUnlocked: true, unlockedAt: new Date().toISOString() };
      }
      if (b.id === 'streak_3') {
        return { ...b, currentValue: 2 };
      }
      if (b.id === 'focus_5h') {
        return { ...b, currentValue: 110 };
      }
      return b;
    });
    this.saveBadges(badges);
    return badges;
  }

  static saveBadges(badges: AchievementBadge[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(badges));
    } catch (e) {
      console.error('Failed to save badges:', e);
    }
  }

  static getRewards(): PersonalReward[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REWARDS);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    this.saveRewards(DEFAULT_PERSONAL_REWARDS);
    return DEFAULT_PERSONAL_REWARDS;
  }

  static saveRewards(rewards: PersonalReward[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.REWARDS, JSON.stringify(rewards));
    } catch (e) {
      console.error('Failed to save rewards:', e);
    }
  }

  static getTotalXp(): number {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TOTAL_XP);
      if (data) return parseInt(data, 10) || 0;
    } catch {
      // fallback
    }
    return 620; // Initial level 3
  }

  static saveTotalXp(xp: number): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TOTAL_XP, xp.toString());
    } catch (e) {
      console.error('Failed to save XP:', e);
    }
  }

  static getNotifications(): AppNotification[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    const initial: AppNotification[] = [
      {
        id: 'notif_welcome',
        title: 'Welcome to LifeOS! 🚀',
        message: 'Your personal routine, study roadmap, and achievement tracker is ready.',
        timestamp: new Date().toISOString(),
        type: 'info',
        read: false,
        linkTab: 'dashboard',
      },
      {
        id: 'notif_streak',
        title: '2-Day Streak Active! 🔥',
        message: 'Complete your pending afternoon sessions to keep your streak blazing.',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        type: 'achievement',
        read: false,
        linkTab: 'achievements',
      },
    ];
    this.saveNotifications(initial);
    return initial;
  }

  static saveNotifications(notifications: AppNotification[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
    } catch (e) {
      console.error('Failed to save notifications:', e);
    }
  }

  static exportFullBackupJSON(): string {
    const backup = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      settings: this.getSettings(),
      routine: this.getRoutine(),
      tasks: this.getTasks(),
      goals: this.getGoals(),
      focusSessions: this.getFocusSessions(),
      badges: this.getBadges(),
      rewards: this.getRewards(),
      totalXp: this.getTotalXp(),
    };
    return JSON.stringify(backup, null, 2);
  }

  static importFullBackupJSON(jsonStr: string): boolean {
    try {
      const data = JSON.parse(jsonStr);
      if (data.settings) this.saveSettings(data.settings);
      if (Array.isArray(data.routine)) this.saveRoutine(data.routine);
      if (Array.isArray(data.tasks)) this.saveTasks(data.tasks);
      if (Array.isArray(data.goals)) this.saveGoals(data.goals);
      if (Array.isArray(data.focusSessions)) this.saveFocusSessions(data.focusSessions);
      if (Array.isArray(data.badges)) this.saveBadges(data.badges);
      if (Array.isArray(data.rewards)) this.saveRewards(data.rewards);
      if (typeof data.totalXp === 'number') this.saveTotalXp(data.totalXp);
      return true;
    } catch (err) {
      console.error('Backup import error:', err);
      return false;
    }
  }

  static resetToDefault(): void {
    localStorage.clear();
    this.saveSettings(DEFAULT_SETTINGS);
    this.saveRoutine(DEFAULT_ROUTINE_ITEMS);
    this.saveTasks(generateInitialTasks(DEFAULT_ROUTINE_ITEMS));
    this.saveGoals(DEFAULT_MONTHLY_GOALS);
    this.saveBadges(INITIAL_ACHIEVEMENT_BADGES);
    this.saveRewards(DEFAULT_PERSONAL_REWARDS);
    this.saveTotalXp(620);
  }
}
