export type CategoryType =
  | 'University'
  | 'Competitive Programming'
  | 'Web Development'
  | 'IELTS'
  | 'Personal'
  | 'Exercise'
  | 'Break'
  | 'Sleep'
  | 'Custom';

export type PriorityType = 'low' | 'medium' | 'high';

export type TaskStatus = 'pending' | 'completed' | 'skipped' | 'rescheduled';

export interface RoutineItem {
  id: string;
  title: string;
  category: CategoryType;
  customCategoryName?: string;
  startTime: string; // "HH:mm" (24-hour)
  endTime: string;   // "HH:mm" (24-hour)
  daysOfWeek: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  isRecurring: boolean;
  specificDate?: string; // "YYYY-MM-DD" if not recurring
  description?: string;
  notes?: string;
  priority: PriorityType;
  reminderMinutes: number; // 5, 10, 15, 30, etc.
  reminderEnabled: boolean;
  targetDurationMinutes: number;
  linkedGoalId?: string;
  color?: string;
  orderIndex: number;
}

export interface TaskRecord {
  id: string;
  routineItemId?: string;
  date: string; // "YYYY-MM-DD"
  title: string;
  category: CategoryType | string;
  startTime: string;
  endTime: string;
  priority: PriorityType;
  status: TaskStatus;
  completedAt?: string; // ISO
  skippedAt?: string;
  pointsAwarded: number;
  notes?: string;
  targetDurationMinutes?: number;
  linkedGoalId?: string;
}

export interface Milestone {
  id: string;
  title: string;
  weekNumber: number;
  completed: boolean;
  dueDate: string;
}

export interface MonthlyGoal {
  id: string;
  month: string; // "YYYY-MM"
  title: string;
  category: CategoryType | string;
  description: string;
  targetCompletionDate: string; // "YYYY-MM-DD"
  priority: PriorityType;
  estimatedHours: number;
  completedHours: number;
  targetMetric?: {
    current: number;
    target: number;
    unit: string;
  };
  milestones: Milestone[];
  isArchived: boolean;
  createdAt: string;
}

export interface FocusSession {
  id: string;
  routineItemId?: string;
  taskTitle: string;
  category: CategoryType | string;
  durationMinutes: number;
  completedAt: string; // ISO
  type: 'pomodoro' | 'short_break' | 'long_break' | 'custom';
  xpEarned: number;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  category: 'daily' | 'monthly' | 'focus' | 'streak' | 'special';
  icon: string;
  xpReward: number;
  unlockedAt?: string;
  targetValue: number;
  currentValue: number;
  isUnlocked: boolean;
}

export interface PersonalReward {
  id: string;
  title: string;
  costXp: number;
  icon: string;
  redeemedCount: number;
  lastRedeemedAt?: string;
}

export interface UserSettings {
  displayName: string;
  timezone: string;
  timeFormat: '12h' | '24h';
  weekStartsOn: 0 | 1; // 0=Sun, 1=Mon
  theme: 'light' | 'dark' | 'system';
  notificationsEnabled: boolean;
  defaultReminderMinutes: number;
  soundAlerts: boolean;
  defaultFocusDuration: number; // 25
  defaultShortBreak: number;    // 5
  defaultLongBreak: number;     // 15
  dailyProductivityTargetHours: number; // e.g. 6
  weeklyStudyTargetHours: number;       // e.g. 35
  autoDetectConflicts: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string; // ISO
  type: 'reminder' | 'achievement' | 'milestone' | 'warning' | 'info';
  read: boolean;
  snoozedUntil?: string;
  linkTab?: string;
}

export interface ScheduleConflict {
  itemA: RoutineItem;
  itemB: RoutineItem;
  dayIndex: number;
  overlapMinutes: number;
}
