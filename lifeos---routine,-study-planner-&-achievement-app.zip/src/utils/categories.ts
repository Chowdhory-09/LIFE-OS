import { CategoryType } from '../types';

export interface CategoryMeta {
  name: CategoryType;
  label: string;
  color: string; // Tailwind color class
  bgLight: string;
  textLight: string;
  bgDark: string;
  textDark: string;
  borderColor: string;
  icon: string; // Lucide icon name representation
}

export const CATEGORIES_CONFIG: Record<CategoryType, CategoryMeta> = {
  'University': {
    name: 'University',
    label: 'University',
    color: '#3b82f6', // blue
    bgLight: 'bg-blue-50',
    textLight: 'text-blue-700',
    bgDark: 'dark:bg-blue-950/60',
    textDark: 'dark:text-blue-300',
    borderColor: 'border-blue-300 dark:border-blue-800',
    icon: 'GraduationCap',
  },
  'Competitive Programming': {
    name: 'Competitive Programming',
    label: 'Competitive Prog',
    color: '#8b5cf6', // purple / violet
    bgLight: 'bg-purple-50',
    textLight: 'text-purple-700',
    bgDark: 'dark:bg-purple-950/60',
    textDark: 'dark:text-purple-300',
    borderColor: 'border-purple-300 dark:border-purple-800',
    icon: 'Code2',
  },
  'Web Development': {
    name: 'Web Development',
    label: 'Web Dev',
    color: '#06b6d4', // cyan
    bgLight: 'bg-cyan-50',
    textLight: 'text-cyan-700',
    bgDark: 'dark:bg-cyan-950/60',
    textDark: 'dark:text-cyan-300',
    borderColor: 'border-cyan-300 dark:border-cyan-800',
    icon: 'Globe',
  },
  'IELTS': {
    name: 'IELTS',
    label: 'IELTS Prep',
    color: '#f59e0b', // amber
    bgLight: 'bg-amber-50',
    textLight: 'text-amber-700',
    bgDark: 'dark:bg-amber-950/60',
    textDark: 'dark:text-amber-300',
    borderColor: 'border-amber-300 dark:border-amber-800',
    icon: 'BookOpen',
  },
  'Personal': {
    name: 'Personal',
    label: 'Personal',
    color: '#ec4899', // pink
    bgLight: 'bg-pink-50',
    textLight: 'text-pink-700',
    bgDark: 'dark:bg-pink-950/60',
    textDark: 'dark:text-pink-300',
    borderColor: 'border-pink-300 dark:border-pink-800',
    icon: 'User',
  },
  'Exercise': {
    name: 'Exercise',
    label: 'Exercise & Fitness',
    color: '#10b981', // emerald
    bgLight: 'bg-emerald-50',
    textLight: 'text-emerald-700',
    bgDark: 'dark:bg-emerald-950/60',
    textDark: 'dark:text-emerald-300',
    borderColor: 'border-emerald-300 dark:border-emerald-800',
    icon: 'Dumbbell',
  },
  'Break': {
    name: 'Break',
    label: 'Break & Meal',
    color: '#f97316', // orange
    bgLight: 'bg-orange-50',
    textLight: 'text-orange-700',
    bgDark: 'dark:bg-orange-950/60',
    textDark: 'dark:text-orange-300',
    borderColor: 'border-orange-300 dark:border-orange-800',
    icon: 'Coffee',
  },
  'Sleep': {
    name: 'Sleep',
    label: 'Sleep & Rest',
    color: '#6366f1', // indigo
    bgLight: 'bg-indigo-50',
    textLight: 'text-indigo-700',
    bgDark: 'dark:bg-indigo-950/60',
    textDark: 'dark:text-indigo-300',
    borderColor: 'border-indigo-300 dark:border-indigo-800',
    icon: 'Moon',
  },
  'Custom': {
    name: 'Custom',
    label: 'Custom Activity',
    color: '#64748b', // slate
    bgLight: 'bg-slate-100',
    textLight: 'text-slate-700',
    bgDark: 'dark:bg-slate-800',
    textDark: 'dark:text-slate-300',
    borderColor: 'border-slate-300 dark:border-slate-700',
    icon: 'Sparkles',
  },
};

export function getCategoryMeta(category: CategoryType | string): CategoryMeta {
  if (category in CATEGORIES_CONFIG) {
    return CATEGORIES_CONFIG[category as CategoryType];
  }
  return {
    ...CATEGORIES_CONFIG['Custom'],
    label: category,
  };
}
