import { RoutineItem, ScheduleConflict } from '../types';

export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.split(':');
  if (parts.length < 2) return 0;
  const h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  return h * 60 + m;
}

export function minutesToTime(mins: number): string {
  const normalized = ((mins % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export function calculateDurationMinutes(startTime: string, endTime: string): number {
  const start = timeToMinutes(startTime);
  let end = timeToMinutes(endTime);
  if (end < start) {
    // Crosses midnight
    end += 1440;
  }
  return end - start;
}

export function formatDuration(minutes: number): string {
  if (minutes < 0) minutes = 0;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function formatTimeDisplay(timeStr: string, format: '12h' | '24h' = '12h'): string {
  if (!timeStr) return '';
  if (format === '24h') return timeStr;
  
  const [hStr, mStr] = timeStr.split(':');
  let h = parseInt(hStr, 10);
  const m = mStr || '00';
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${ampm}`;
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentMonthString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  return `${year}-${month}`;
}

export function getDayOfWeekIndex(dateStr?: string): number {
  if (dateStr) {
    const d = new Date(dateStr + 'T00:00:00');
    return d.getDay();
  }
  return new Date().getDay(); // 0 = Sunday, 1 = Monday, ...
}

export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const SHORT_DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function detectConflictsForDay(items: RoutineItem[], dayIndex: number): ScheduleConflict[] {
  const dayItems = items.filter((item) => {
    if (!item.isRecurring && item.specificDate) {
      const itemDayIndex = getDayOfWeekIndex(item.specificDate);
      return itemDayIndex === dayIndex;
    }
    return item.daysOfWeek.includes(dayIndex);
  });

  const conflicts: ScheduleConflict[] = [];

  for (let i = 0; i < dayItems.length; i++) {
    for (let j = i + 1; j < dayItems.length; j++) {
      const a = dayItems[i];
      const b = dayItems[j];

      const aStart = timeToMinutes(a.startTime);
      const aEnd = aStart + calculateDurationMinutes(a.startTime, a.endTime);

      const bStart = timeToMinutes(b.startTime);
      const bEnd = bStart + calculateDurationMinutes(b.startTime, b.endTime);

      // Check overlap: max(startA, startB) < min(endA, endB)
      const overlapStart = Math.max(aStart, bStart);
      const overlapEnd = Math.min(aEnd, bEnd);

      if (overlapStart < overlapEnd) {
        conflicts.push({
          itemA: a,
          itemB: b,
          dayIndex,
          overlapMinutes: overlapEnd - overlapStart,
        });
      }
    }
  }

  return conflicts;
}

export function getNextTaskInfo(
  items: RoutineItem[],
  currentDate: string = getTodayDateString(),
  currentTimeMinutes: number = new Date().getHours() * 60 + new Date().getMinutes()
): {
  nextItem: RoutineItem | null;
  currentActiveItem: RoutineItem | null;
  countdownMinutes: number | null;
  remainingMinutesInActive: number | null;
} {
  const dayIndex = getDayOfWeekIndex(currentDate);

  const todayItems = items.filter((item) => {
    if (!item.isRecurring && item.specificDate) {
      return item.specificDate === currentDate;
    }
    return item.daysOfWeek.includes(dayIndex);
  });

  // Sort by start time
  todayItems.sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  let currentActiveItem: RoutineItem | null = null;
  let remainingMinutesInActive: number | null = null;
  let nextItem: RoutineItem | null = null;
  let countdownMinutes: number | null = null;

  for (const item of todayItems) {
    const startM = timeToMinutes(item.startTime);
    const endM = startM + calculateDurationMinutes(item.startTime, item.endTime);

    if (currentTimeMinutes >= startM && currentTimeMinutes < endM) {
      currentActiveItem = item;
      remainingMinutesInActive = endM - currentTimeMinutes;
    } else if (startM > currentTimeMinutes) {
      if (!nextItem) {
        nextItem = item;
        countdownMinutes = startM - currentTimeMinutes;
      }
    }
  }

  return {
    nextItem,
    currentActiveItem,
    countdownMinutes,
    remainingMinutesInActive,
  };
}
