export type ThemeMode = 'light' | 'dark' | 'system';

export function getEffectiveIsDark(theme: ThemeMode): boolean {
  if (typeof window === 'undefined') return true;
  if (theme === 'dark') return true;
  if (theme === 'light') return false;
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
}

export function applyTheme(theme: ThemeMode): boolean {
  if (typeof document === 'undefined') return true;
  const isDark = getEffectiveIsDark(theme);
  if (isDark) {
    document.documentElement.classList.add('dark');
    document.documentElement.style.colorScheme = 'dark';
  } else {
    document.documentElement.classList.remove('dark');
    document.documentElement.style.colorScheme = 'light';
  }
  return isDark;
}
