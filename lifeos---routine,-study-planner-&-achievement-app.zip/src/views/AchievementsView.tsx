import React, { useState } from 'react';
import {
  Award,
  Flame,
  Gift,
  Plus,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  Lock,
  Crown,
  Coffee,
  Gamepad2,
  Film,
  ShoppingBag,
} from 'lucide-react';
import { AchievementBadge, PersonalReward, TaskRecord } from '../types';
import { calculateLevel, fireCelebrationConfetti } from '../services/gamification';
import { playChime } from '../services/audio';

interface AchievementsViewProps {
  totalXp: number;
  streakCount: number;
  bestStreak: number;
  badges: AchievementBadge[];
  personalRewards: PersonalReward[];
  onRedeemReward: (rewardId: string, cost: number) => void;
  onAddCustomReward: (reward: PersonalReward) => void;
}

export const AchievementsView: React.FC<AchievementsViewProps> = ({
  totalXp,
  streakCount,
  bestStreak,
  badges,
  personalRewards,
  onRedeemReward,
  onAddCustomReward,
}) => {
  const [badgeCategory, setBadgeCategory] = useState<'all' | 'daily' | 'monthly' | 'focus' | 'streak'>('all');
  const [showAddRewardModal, setShowAddRewardModal] = useState(false);
  const [newRewardTitle, setNewRewardTitle] = useState('');
  const [newRewardCost, setNewRewardCost] = useState(150);
  const [newRewardIcon, setNewRewardIcon] = useState('Gamepad2');

  const levelInfo = calculateLevel(totalXp);

  const filteredBadges = badges.filter((b) => {
    if (badgeCategory === 'all') return true;
    return b.category === badgeCategory;
  });

  const unlockedCount = badges.filter((b) => b.isUnlocked).length;

  const handleRedeem = (reward: PersonalReward) => {
    if (totalXp < reward.costXp) {
      alert(`You need ${reward.costXp} XP to unlock this reward. Keep completing tasks to earn more!`);
      return;
    }
    playChime('achievement');
    fireCelebrationConfetti();
    onRedeemReward(reward.id, reward.costXp);
  };

  const handleCreateReward = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRewardTitle.trim()) return;

    const reward: PersonalReward = {
      id: 'rew_' + Date.now(),
      title: newRewardTitle.trim(),
      costXp: newRewardCost,
      icon: newRewardIcon,
      redeemedCount: 0,
    };
    onAddCustomReward(reward);
    setShowAddRewardModal(false);
    setNewRewardTitle('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-500" />
            Achievements, XP & Rewards
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Gamified productivity engine. Unlock achievement badges and redeem earned XP for personal rewards.
          </p>
        </div>

        <button
          onClick={() => setShowAddRewardModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add Custom Reward</span>
        </button>
      </div>

      {/* Level & Rank Showcase Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-purple-950 to-slate-900 p-6 md:p-8 text-white shadow-xl border border-indigo-800/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="relative w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black text-2xl md:text-3xl shadow-lg shadow-amber-500/30 shrink-0">
              <Crown className="w-9 h-9 text-slate-900" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  {levelInfo.rankTitle}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-mono">
                  Level {levelInfo.level}
                </span>
              </div>
              <h3 className="text-2xl md:text-3xl font-black tracking-tight">
                {totalXp} Total XP Earned
              </h3>
              <p className="text-xs text-slate-300">
                {levelInfo.xpForNextLevel - totalXp} XP needed for Level {levelInfo.level + 1}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-right">
              <span className="text-xs text-slate-300 block">Active Streak</span>
              <span className="text-2xl font-black text-amber-400 flex items-center justify-end gap-1">
                <Flame className="w-5 h-5 fill-amber-400" />
                {streakCount} {streakCount === 1 ? 'day' : 'days'}
              </span>
              <span className="text-[10px] text-slate-400">Best: {bestStreak} days</span>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-300 block">Badges Unlocked</span>
              <span className="text-2xl font-black text-indigo-300">
                {unlockedCount}/{badges.length}
              </span>
              <span className="text-[10px] text-slate-400">Mastery status</span>
            </div>
          </div>
        </div>

        {/* Progress Bar inside banner */}
        <div className="mt-6 w-full bg-black/40 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-amber-400 to-indigo-400 h-full rounded-full transition-all duration-700"
            style={{ width: `${levelInfo.progressPercent}%` }}
          />
        </div>
      </div>

      {/* Badges Section */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Achievement Badges
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Real accomplishments awarded based on disciplined routines and study sessions.
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold">
            {(['all', 'daily', 'monthly', 'focus', 'streak'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setBadgeCategory(cat)}
                className={`px-3 py-1 rounded-lg capitalize transition ${
                  badgeCategory === cat
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBadges.map((badge) => {
            const progress = Math.min(100, Math.round((badge.currentValue / badge.targetValue) * 100));

            return (
              <div
                key={badge.id}
                className={`p-4 rounded-2xl border transition relative flex flex-col justify-between space-y-3 ${
                  badge.isUnlocked
                    ? 'bg-gradient-to-br from-amber-500/5 via-indigo-500/5 to-transparent border-amber-300 dark:border-amber-700/50 shadow-xs'
                    : 'bg-slate-50/50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-70'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        badge.isUnlocked
                          ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 shadow-xs'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
                      }`}
                    >
                      {badge.isUnlocked ? (
                        <Award className="w-5 h-5 fill-amber-500/30" />
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {badge.title}
                      </h4>
                      <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">
                        +{badge.xpReward} XP
                      </span>
                    </div>
                  </div>

                  {badge.isUnlocked && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                      Unlocked
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {badge.description}
                </p>

                {/* Progress bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span>Progress: {badge.currentValue}/{badge.targetValue}</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        badge.isUnlocked ? 'bg-amber-500' : 'bg-slate-400'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Personal Custom Rewards Store */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Gift className="w-4 h-4 text-purple-500" />
              Personal Rewards Store
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Spend earned XP to treat yourself guilt-free after hitting your study and routine targets.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
            <span>Available XP:</span>
            <span className="text-indigo-600 dark:text-indigo-400">{totalXp} XP</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {personalRewards.map((reward) => {
            const canAfford = totalXp >= reward.costXp;

            return (
              <div
                key={reward.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 flex flex-col justify-between space-y-4 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                    <Gift className="w-5 h-5" />
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-[10px] font-mono">
                    Redeemed: {reward.redeemedCount}x
                  </span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {reward.title}
                  </h4>
                  <p className="text-[11px] font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-0.5">
                    Cost: {reward.costXp} XP
                  </p>
                </div>

                <button
                  onClick={() => handleRedeem(reward)}
                  disabled={!canAfford}
                  className={`w-full py-2 rounded-xl text-xs font-semibold transition shadow-xs ${
                    canAfford
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/25 active:scale-95'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {canAfford ? 'Redeem Reward' : `Need ${reward.costXp - totalXp} more XP`}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Custom Reward Modal */}
      {showAddRewardModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              Define Custom Personal Reward
            </h3>

            <form onSubmit={handleCreateReward} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Reward Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 1 Hour Video Games, Favorite Dessert, Weekend Movie"
                  value={newRewardTitle}
                  onChange={(e) => setNewRewardTitle(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  XP Cost (Points)
                </label>
                <input
                  type="number"
                  min="25"
                  step="25"
                  value={newRewardCost}
                  onChange={(e) => setNewRewardCost(parseInt(e.target.value, 10) || 25)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddRewardModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30"
                >
                  Save Reward
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
