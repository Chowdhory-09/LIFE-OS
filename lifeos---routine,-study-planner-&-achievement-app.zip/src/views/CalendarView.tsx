import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Clock,
  Target,
  Plus,
  Circle,
} from 'lucide-react';
import { MonthlyGoal, RoutineItem, TaskRecord, UserSettings } from '../types';
import { getCategoryMeta } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTimeDisplay,
  getDayOfWeekIndex,
  getTodayDateString,
  timeToMinutes,
} from '../utils/schedule';

interface CalendarViewProps {
  routineItems: RoutineItem[];
  taskRecords: TaskRecord[];
  monthlyGoals: MonthlyGoal[];
  settings: UserSettings;
  onToggleTaskCompletion: (taskTitle: string, routineItem?: RoutineItem) => void;
  onOpenAddRoutineModal: () => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  routineItems,
  taskRecords,
  monthlyGoals,
  settings,
  onToggleTaskCompletion,
  onOpenAddRoutineModal,
}) => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDayString, setSelectedDayString] = useState<string>(getTodayDateString());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Navigation handlers
  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDayString(getTodayDateString());
  };

  // Selected day items
  const selectedDayIndex = getDayOfWeekIndex(selectedDayString);
  const scheduledForSelectedDay = routineItems
    .filter((item) => {
      if (!item.isRecurring && item.specificDate) {
        return item.specificDate === selectedDayString;
      }
      return item.daysOfWeek.includes(selectedDayIndex);
    })
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  const recordsForSelectedDay = taskRecords.filter((t) => t.date === selectedDayString);

  // Goals / Milestones due on selected day
  const milestonesDueOnSelectedDay: { goalTitle: string; milestoneTitle: string }[] = [];
  monthlyGoals.forEach((g) => {
    g.milestones.forEach((m) => {
      if (m.dueDate === selectedDayString) {
        milestonesDueOnSelectedDay.push({ goalTitle: g.title, milestoneTitle: m.title });
      }
    });
  });

  // Calendar cells builder
  const daysArray: (number | null)[] = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    daysArray.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    daysArray.push(d);
  }

  const weekDayHeaders = settings.weekStartsOn === 1 
    ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] 
    : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6 pb-12">
      {/* Calendar Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-indigo-500" />
            Calendar & Deadlines
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Interactive schedule viewer linking daily routines and monthly roadmap milestones.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleToday}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50"
          >
            Today
          </button>
          <div className="flex items-center rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-0.5">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-3 text-xs font-bold font-mono text-slate-800 dark:text-slate-200">
              {monthNames[month]} {year}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid (2 Cols) */}
        <div className="lg:col-span-2 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm">
          <div className="grid grid-cols-7 gap-2 mb-3">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div
                key={day}
                className="text-center text-[11px] font-bold uppercase tracking-wider text-slate-400 py-1"
              >
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
            {daysArray.map((dayNum, idx) => {
              if (dayNum === null) {
                return <div key={`empty_${idx}`} className="h-16 sm:h-20 rounded-xl bg-slate-50/40 dark:bg-slate-900/20" />;
              }

              const formattedDayStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${dayNum.toString().padStart(2, '0')}`;
              const isSelected = formattedDayStr === selectedDayString;
              const isToday = formattedDayStr === getTodayDateString();

              const dayOfWeek = new Date(year, month, dayNum).getDay();
              const scheduledCount = routineItems.filter((i) => i.daysOfWeek.includes(dayOfWeek)).length;
              const completedCount = taskRecords.filter((t) => t.date === formattedDayStr && t.status === 'completed').length;

              // Check if any milestone due
              const hasMilestone = monthlyGoals.some((g) =>
                g.milestones.some((m) => m.dueDate === formattedDayStr)
              );

              return (
                <button
                  key={formattedDayStr}
                  onClick={() => setSelectedDayString(formattedDayStr)}
                  className={`group relative flex flex-col justify-between p-2 h-16 sm:h-20 rounded-2xl border text-left transition ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 ring-2 ring-indigo-500/20'
                      : isToday
                      ? 'border-indigo-400 dark:border-indigo-700 bg-slate-50 dark:bg-slate-800/60'
                      : 'border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-xs font-bold ${
                        isToday
                          ? 'px-1.5 py-0.5 rounded-full bg-indigo-600 text-white font-mono text-[11px]'
                          : isSelected
                          ? 'text-indigo-600 dark:text-indigo-400 font-mono'
                          : 'text-slate-700 dark:text-slate-300 font-mono'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {hasMilestone && (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-500/30" title="Milestone Deadline" />
                    )}
                  </div>

                  {scheduledCount > 0 && (
                    <div className="w-full space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400">
                        <span>{completedCount}/{scheduledCount}</span>
                        {completedCount === scheduledCount && completedCount > 0 && (
                          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        )}
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full rounded-full"
                          style={{
                            width: `${Math.min(100, Math.round((completedCount / scheduledCount) * 100))}%`,
                          }}
                        />
                      </div>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Day Agenda Drawer */}
        <div className="space-y-4">
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                  Agenda for
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {new Date(selectedDayString + 'T00:00:00').toLocaleDateString([], {
                    weekday: 'long',
                    month: 'short',
                    day: 'numeric',
                  })}
                </h3>
              </div>
              <span className="text-xs font-mono font-semibold text-slate-500">
                {scheduledForSelectedDay.length} items
              </span>
            </div>

            {/* Milestones Alert if any */}
            {milestonesDueOnSelectedDay.length > 0 && (
              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 space-y-1 text-xs">
                <div className="flex items-center gap-1.5 font-bold">
                  <Target className="w-3.5 h-3.5 text-amber-600" />
                  Roadmap Deadlines Today:
                </div>
                {milestonesDueOnSelectedDay.map((m, idx) => (
                  <div key={idx} className="pl-5 text-[11px]">
                    • <strong>{m.milestoneTitle}</strong> ({m.goalTitle})
                  </div>
                ))}
              </div>
            )}

            {/* Activities list for selected day */}
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {scheduledForSelectedDay.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400 space-y-2">
                  <Clock className="w-6 h-6 mx-auto text-slate-300" />
                  <p>No scheduled tasks on this date.</p>
                  <button
                    onClick={onOpenAddRoutineModal}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold"
                  >
                    <Plus className="w-3 h-3" /> Add Task
                  </button>
                </div>
              ) : (
                scheduledForSelectedDay.map((item) => {
                  const meta = getCategoryMeta(item.category);
                  const duration = calculateDurationMinutes(item.startTime, item.endTime);
                  const matchingRecord = recordsForSelectedDay.find(
                    (r) => r.routineItemId === item.id || r.title === item.title
                  );
                  const isDone = matchingRecord?.status === 'completed';

                  return (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-50 transition"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          onClick={() => onToggleTaskCompletion(item.title, item)}
                          className="shrink-0 text-slate-400 hover:text-indigo-600 transition"
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500/20" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </button>
                        <div className="min-w-0">
                          <p className={`text-xs font-bold truncate ${isDone ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                            {item.title}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            {formatTimeDisplay(item.startTime, settings.timeFormat)} - {formatTimeDisplay(item.endTime, settings.timeFormat)} ({formatDuration(duration)})
                          </p>
                        </div>
                      </div>

                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded border shrink-0 ${meta.bgLight} ${meta.textLight} ${meta.bgDark} ${meta.textDark} ${meta.borderColor}`}
                      >
                        {meta.label}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
