import React from 'react';
import {
  CheckCircle2,
  Circle,
  Clock,
  Flame,
  Plus,
  Play,
  RotateCcw,
  SkipForward,
  Sparkles,
  Target,
  Timer,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  ChevronRight,
} from 'lucide-react';
import {
  MonthlyGoal,
  RoutineItem,
  TaskRecord,
  UserSettings,
} from '../types';
import { getCategoryMeta } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTimeDisplay,
  getNextTaskInfo,
  getTodayDateString,
  timeToMinutes,
} from '../utils/schedule';
import { calculateLevel } from '../services/gamification';

interface DashboardViewProps {
  routineItems: RoutineItem[];
  taskRecords: TaskRecord[];
  monthlyGoals: MonthlyGoal[];
  totalXp: number;
  streakCount: number;
  settings: UserSettings;
  onToggleTaskCompletion: (taskTitle: string, routineItem?: RoutineItem) => void;
  onSkipTask: (taskTitle: string, routineItem?: RoutineItem) => void;
  onUndoTask: (taskId: string) => void;
  onNavigateTab: (tab: string) => void;
  onStartFocusOnTask: (taskTitle: string, category: string, routineId?: string) => void;
  onOpenAddRoutineModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  routineItems,
  taskRecords,
  monthlyGoals,
  totalXp,
  streakCount,
  settings,
  onToggleTaskCompletion,
  onSkipTask,
  onUndoTask,
  onNavigateTab,
  onStartFocusOnTask,
  onOpenAddRoutineModal,
}) => {
  const todayStr = getTodayDateString();
  const todayDayOfWeek = new Date().getDay();
  const currentHour = new Date().getHours();

  // Dynamic greeting
  let greeting = 'Good morning';
  let greetingEmoji = '☀️';
  if (currentHour >= 12 && currentHour < 17) {
    greeting = 'Good afternoon';
    greetingEmoji = '🌤️';
  } else if (currentHour >= 17 && currentHour < 22) {
    greeting = 'Good evening';
    greetingEmoji = '🌆';
  } else if (currentHour >= 22 || currentHour < 5) {
    greeting = 'Night owl time';
    greetingEmoji = '🌙';
  }

  // Get scheduled items for today
  const todayScheduledItems = routineItems
    .filter((item) => {
      if (!item.isRecurring && item.specificDate) {
        return item.specificDate === todayStr;
      }
      return item.daysOfWeek.includes(todayDayOfWeek);
    })
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  // Today's task records
  const todayRecords = taskRecords.filter((t) => t.date === todayStr);

  const completedRecords = todayRecords.filter((t) => t.status === 'completed');
  const skippedRecords = todayRecords.filter((t) => t.status === 'skipped');

  const totalTasks = todayScheduledItems.length;
  const completedCount = completedRecords.length;
  const completionPercent = totalTasks > 0 ? Math.min(100, Math.round((completedCount / totalTasks) * 100)) : 0;
  const remainingCount = Math.max(0, totalTasks - completedCount - skippedRecords.length);

  // Focus time calculation for today
  const todayStudyMinutes = completedRecords.reduce((acc, t) => {
    return acc + (t.targetDurationMinutes || 45);
  }, 0);

  // Next task countdown
  const nextTaskData = getNextTaskInfo(routineItems, todayStr);
  const levelInfo = calculateLevel(totalXp);

  // Motivational message based on actual progress
  let motivationalMessage = 'Start strong today! Every disciplined step builds your future.';
  if (completionPercent >= 100) {
    motivationalMessage = 'Incredible dedication! You completed all planned routine activities today! 🏆';
  } else if (completionPercent >= 75) {
    motivationalMessage = 'Almost at the finish line! Finish your remaining tasks with pride.';
  } else if (completionPercent >= 50) {
    motivationalMessage = 'Over halfway there! Excellent consistency and focus so far.';
  } else if (completedCount > 0) {
    motivationalMessage = 'Great start! Maintain the momentum through your next study block.';
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 text-white shadow-xl border border-indigo-900/40">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 -mb-10 h-40 w-40 rounded-full bg-violet-500/10 blur-2xl" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-indigo-200 border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
              <span>Personal Operating System</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              {greeting}, {settings.displayName}! {greetingEmoji}
            </h2>
            <p className="text-sm md:text-base text-slate-300 max-w-xl">
              {motivationalMessage}
            </p>
          </div>

          {/* Quick Action buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigateTab('focus')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition active:scale-95"
            >
              <Timer className="w-4 h-4" />
              <span>Start Focus</span>
            </button>
            <button
              onClick={onOpenAddRoutineModal}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-semibold text-sm backdrop-blur-md border border-white/20 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Add Routine</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Completion Ring Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Daily Completion</span>
            <span className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {completionPercent}%
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              ({completedCount}/{totalTasks} tasks)
            </span>
          </div>
          <div className="mt-3 w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full rounded-full transition-all duration-700"
              style={{ width: `${completionPercent}%` }}
            />
          </div>
        </div>

        {/* Focus & Study Hours */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Study & Focus Time</span>
            <span className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {formatDuration(todayStudyMinutes)}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              / {settings.dailyProductivityTargetHours}h target
            </span>
          </div>
          <div className="mt-3 w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-purple-600 h-full rounded-full transition-all duration-700"
              style={{
                width: `${Math.min(100, Math.round((todayStudyMinutes / (settings.dailyProductivityTargetHours * 60)) * 100))}%`,
              }}
            />
          </div>
        </div>

        {/* Streak Counter */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Active Streak</span>
            <span className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Flame className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {streakCount}
            </span>
            <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
              {streakCount > 0 ? 'Days on Fire' : 'Start Today'}
            </span>
          </div>
          <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {remainingCount > 0 ? `${remainingCount} tasks left today` : 'Daily target achieved!'}
          </p>
        </div>

        {/* Level & Points */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Total Points & Level</span>
            <span className="p-2 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {totalXp}
            </span>
            <span className="text-xs text-indigo-600 dark:text-indigo-400 font-bold">
              Level {levelInfo.level}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>{levelInfo.progressPercent}% to Lvl {levelInfo.level + 1}</span>
            <span>{levelInfo.rankTitle}</span>
          </div>
        </div>
      </div>

      {/* Next Scheduled Task Live Countdown Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 border border-indigo-500/20 p-4 md:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
            <Clock className="w-5 h-5 animate-spin" style={{ animationDuration: '8s' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                {nextTaskData.currentActiveItem ? 'Active Right Now' : 'Up Next on Schedule'}
              </span>
              {nextTaskData.currentActiveItem && (
                <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
              )}
            </div>
            <h3 className="text-base md:text-lg font-bold text-slate-900 dark:text-white">
              {nextTaskData.currentActiveItem
                ? nextTaskData.currentActiveItem.title
                : nextTaskData.nextItem
                ? nextTaskData.nextItem.title
                : 'All scheduled routine items for today have ended'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              {nextTaskData.currentActiveItem ? (
                <>Ends in {formatDuration(nextTaskData.remainingMinutesInActive || 0)} • {formatTimeDisplay(nextTaskData.currentActiveItem.startTime, settings.timeFormat)} - {formatTimeDisplay(nextTaskData.currentActiveItem.endTime, settings.timeFormat)}</>
              ) : nextTaskData.nextItem ? (
                <>Starts in {formatDuration(nextTaskData.countdownMinutes || 0)} • at {formatTimeDisplay(nextTaskData.nextItem.startTime, settings.timeFormat)}</>
              ) : (
                'Review your completed achievements or relax for the evening'
              )}
            </p>
          </div>
        </div>

        {(nextTaskData.currentActiveItem || nextTaskData.nextItem) && (
          <button
            onClick={() => {
              const target = nextTaskData.currentActiveItem || nextTaskData.nextItem;
              if (target) {
                onStartFocusOnTask(target.title, target.category, target.id);
              }
            }}
            className="self-start md:self-auto flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 font-semibold text-xs shadow-sm hover:border-indigo-500 transition active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-indigo-600 text-indigo-600" />
            <span>Focus This Task</span>
          </button>
        )}
      </div>

      {/* Main Content Layout: Timetable (Left/Main) & Goals/Sidebar (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Timetable List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Today's Schedule & Routine
                <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {todayScheduledItems.length} items
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Click the checkbox when completed to earn XP and advance your streak.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('routine')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <span>Manage Routine</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {todayScheduledItems.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                  No routine items scheduled for today.
                </p>
                <button
                  onClick={onOpenAddRoutineModal}
                  className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Task for Today
                </button>
              </div>
            ) : (
              todayScheduledItems.map((item) => {
                const categoryMeta = getCategoryMeta(item.category);
                const matchingRecord = todayRecords.find(
                  (r) => (r.routineItemId === item.id || r.title === item.title) && r.date === todayStr
                );
                const isCompleted = matchingRecord?.status === 'completed';
                const isSkipped = matchingRecord?.status === 'skipped';
                const duration = calculateDurationMinutes(item.startTime, item.endTime);

                return (
                  <div
                    key={item.id}
                    className={`group relative flex items-start sm:items-center justify-between p-4 rounded-2xl border transition-all ${
                      isCompleted
                        ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800/60 opacity-80'
                        : isSkipped
                        ? 'bg-slate-100/50 dark:bg-slate-900/30 border-slate-200 dark:border-slate-800 line-through opacity-50'
                        : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 shadow-sm'
                    }`}
                  >
                    <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                      {/* Checkbox button */}
                      <button
                        onClick={() => {
                          if (isCompleted && matchingRecord) {
                            onUndoTask(matchingRecord.id);
                          } else {
                            onToggleTaskCompletion(item.title, item);
                          }
                        }}
                        className="mt-0.5 sm:mt-0 shrink-0 text-slate-300 dark:text-slate-600 hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                        title={isCompleted ? 'Undo completion' : 'Mark completed (+XP)'}
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-500/20" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4
                            className={`text-sm font-bold truncate ${
                              isCompleted
                                ? 'text-slate-500 dark:text-slate-400 line-through'
                                : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {item.title}
                          </h4>

                          {/* Category Badge */}
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${categoryMeta.bgLight} ${categoryMeta.textLight} ${categoryMeta.bgDark} ${categoryMeta.textDark} ${categoryMeta.borderColor}`}
                          >
                            {categoryMeta.label}
                          </span>

                          {/* Priority Indicator */}
                          {item.priority === 'high' && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800">
                              HIGH
                            </span>
                          )}
                        </div>

                        <div className="mt-1 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                          <span className="font-mono">
                            {formatTimeDisplay(item.startTime, settings.timeFormat)} - {formatTimeDisplay(item.endTime, settings.timeFormat)}
                          </span>
                          <span>•</span>
                          <span>{formatDuration(duration)}</span>
                          {isCompleted && matchingRecord?.completedAt && (
                            <>
                              <span>•</span>
                              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                                Done at {new Date(matchingRecord.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (+{matchingRecord.pointsAwarded} XP)
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions on task item */}
                    <div className="flex items-center gap-1.5 pl-3 shrink-0">
                      {!isCompleted && !isSkipped && (
                        <>
                          <button
                            onClick={() => onStartFocusOnTask(item.title, item.category, item.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition"
                            title="Start Pomodoro Focus"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onSkipTask(item.title, item)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition"
                            title="Mark as Skipped"
                          >
                            <SkipForward className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      {isCompleted && matchingRecord && (
                        <button
                          onClick={() => onUndoTask(matchingRecord.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                          title="Undo"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Sidebar Widgets: Monthly Goal Snapshot & Achievements */}
        <div className="space-y-6">
          {/* Active Monthly Goals Widget */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-500" />
                Monthly Goals Progress
              </h3>
              <button
                onClick={() => onNavigateTab('roadmap')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5"
              >
                <span>Roadmap</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3.5">
              {monthlyGoals.slice(0, 3).map((goal) => {
                const completedMilestones = goal.milestones.filter((m) => m.completed).length;
                const totalMilestones = goal.milestones.length;
                const percent = totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0;

                return (
                  <div key={goal.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]">
                        {goal.title}
                      </span>
                      <span className="font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                        {goal.targetMetric
                          ? `${goal.targetMetric.current}/${goal.targetMetric.target} ${goal.targetMetric.unit}`
                          : `${percent}%`}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Productivity Consistency Widget */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/60 to-purple-50/60 dark:from-indigo-950/30 dark:to-purple-950/30 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-300">
                Consistency Tip
              </h4>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Research demonstrates that completing your highest priority routine task within the first 3 hours of your day increases overall habit persistence by over 68%.
            </p>
            <div className="pt-1 flex items-center justify-between text-[11px]">
              <span className="text-indigo-600 dark:text-indigo-400 font-semibold">
                Streak Multiplier: +10% XP
              </span>
              <button
                onClick={() => onNavigateTab('achievements')}
                className="text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-300 font-medium"
              >
                View Rewards →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
