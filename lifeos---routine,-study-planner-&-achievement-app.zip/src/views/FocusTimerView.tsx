import React, { useEffect, useRef, useState } from 'react';
import {
  Timer,
  Clock,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  CheckCircle2,
  Volume2,
  VolumeX,
  Sparkles,
  Flame,
  Award,
  Music,
} from 'lucide-react';
import { CategoryType, FocusSession, RoutineItem, UserSettings } from '../types';
import { CATEGORIES_CONFIG, getCategoryMeta } from '../utils/categories';
import { formatDuration, getTodayDateString } from '../utils/schedule';
import { ambientEngine, playChime } from '../services/audio';
import { fireCelebrationConfetti } from '../services/gamification';

interface FocusTimerViewProps {
  routineItems: RoutineItem[];
  settings: UserSettings;
  focusSessions: FocusSession[];
  onRecordSession: (session: FocusSession) => void;
  preselectedTaskTitle?: string;
  preselectedCategory?: string;
}

export const FocusTimerView: React.FC<FocusTimerViewProps> = ({
  routineItems,
  settings,
  focusSessions,
  onRecordSession,
  preselectedTaskTitle,
  preselectedCategory,
}) => {
  const [mode, setMode] = useState<'focus' | 'short_break' | 'long_break'>('focus');
  const [customFocusMinutes, setCustomFocusMinutes] = useState(settings.defaultFocusDuration || 25);
  const [secondsRemaining, setSecondsRemaining] = useState(customFocusMinutes * 60);
  const [isActive, setIsActive] = useState(false);
  const [linkedTitle, setLinkedTitle] = useState(preselectedTaskTitle || 'Competitive Programming Practice');
  const [linkedCategory, setLinkedCategory] = useState<CategoryType>((preselectedCategory as CategoryType) || 'Competitive Programming');

  // Ambient sound state
  const [ambientSound, setAmbientSound] = useState<'none' | 'rain' | 'binaural' | 'whitenoise'>('none');
  const [ambientVolume, setAmbientVolume] = useState(0.25);

  const initialTotalSeconds =
    mode === 'focus'
      ? customFocusMinutes * 60
      : mode === 'short_break'
      ? settings.defaultShortBreak * 60
      : settings.defaultLongBreak * 60;

  // Sync when mode changes
  const handleModeChange = (newMode: 'focus' | 'short_break' | 'long_break') => {
    setIsActive(false);
    setMode(newMode);
    if (newMode === 'focus') setSecondsRemaining(customFocusMinutes * 60);
    else if (newMode === 'short_break') setSecondsRemaining(settings.defaultShortBreak * 60);
    else setSecondsRemaining(settings.defaultLongBreak * 60);
  };

  useEffect(() => {
    if (preselectedTaskTitle) setLinkedTitle(preselectedTaskTitle);
    if (preselectedCategory) setLinkedCategory(preselectedCategory as CategoryType);
  }, [preselectedTaskTitle, preselectedCategory]);

  // Main countdown timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isActive && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (secondsRemaining === 0 && isActive) {
      // Completed timer!
      setIsActive(false);
      ambientEngine.stop();
      setAmbientSound('none');

      if (settings.soundAlerts) {
        playChime('timer');
      }

      if (mode === 'focus') {
        const earnedXp = Math.max(10, Math.round((customFocusMinutes / 10) * 10));
        fireCelebrationConfetti();

        const session: FocusSession = {
          id: 'focus_' + Date.now(),
          taskTitle: linkedTitle,
          category: linkedCategory,
          durationMinutes: customFocusMinutes,
          completedAt: new Date().toISOString(),
          type: 'pomodoro',
          xpEarned: earnedXp,
        };
        onRecordSession(session);
      }
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, secondsRemaining, mode, customFocusMinutes, linkedTitle, linkedCategory, settings.soundAlerts]);

  // Handle ambient sound toggle
  const handleToggleAmbient = (type: 'rain' | 'binaural' | 'whitenoise') => {
    if (ambientSound === type) {
      ambientEngine.stop();
      setAmbientSound('none');
    } else {
      ambientEngine.start(type, ambientVolume);
      setAmbientSound(type);
    }
  };

  const handleVolumeChange = (vol: number) => {
    setAmbientVolume(vol);
    ambientEngine.setVolume(vol);
  };

  const handleReset = () => {
    setIsActive(false);
    setSecondsRemaining(initialTotalSeconds);
  };

  const handleSkip = () => {
    setIsActive(false);
    playChime('skip');
    if (mode === 'focus') handleModeChange('short_break');
    else handleModeChange('focus');
  };

  // Progress calculations
  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const progressPercent = initialTotalSeconds > 0 ? ((initialTotalSeconds - secondsRemaining) / initialTotalSeconds) * 100 : 0;

  // Daily focus statistics
  const todayStr = getTodayDateString();
  const todayFocusMinutes = focusSessions
    .filter((s) => s.completedAt.startsWith(todayStr))
    .reduce((acc, s) => acc + s.durationMinutes, 0);

  const completedTodayCount = focusSessions.filter((s) => s.completedAt.startsWith(todayStr)).length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Timer className="w-5 h-5 text-indigo-500" />
            Pomodoro & Focus Timer
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Work in deep undistracted sprints, synthesize soothing soundscapes, and earn focus XP.
          </p>
        </div>

        {/* Quick today focus counter */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-700 dark:text-indigo-300 font-semibold">
          <Clock className="w-4 h-4 text-indigo-500" />
          <span>Focused Today: {formatDuration(todayFocusMinutes)} ({completedTodayCount} sessions)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Timer Dial (2 Cols) */}
        <div className="lg:col-span-2 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 md:p-8 shadow-sm flex flex-col items-center justify-center space-y-6 relative overflow-hidden">
          {/* Mode Switcher Buttons */}
          <div className="flex items-center p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold">
            <button
              onClick={() => handleModeChange('focus')}
              className={`px-4 py-2 rounded-xl transition ${
                mode === 'focus'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Focus ({customFocusMinutes}m)
            </button>
            <button
              onClick={() => handleModeChange('short_break')}
              className={`px-4 py-2 rounded-xl transition ${
                mode === 'short_break'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Short Break ({settings.defaultShortBreak}m)
            </button>
            <button
              onClick={() => handleModeChange('long_break')}
              className={`px-4 py-2 rounded-xl transition ${
                mode === 'long_break'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Long Break ({settings.defaultLongBreak}m)
            </button>
          </div>

          {/* Linked Subject Pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
            <span className="text-slate-400 font-medium">Session Goal:</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 max-w-[240px] truncate">
              {linkedTitle}
            </span>
          </div>

          {/* Big Circular Display */}
          <div className="relative w-64 h-64 md:w-72 md:h-72 flex items-center justify-center">
            {/* SVG Ring Background */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 240 240">
              <circle
                cx="120"
                cy="120"
                r="100"
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                className="text-slate-100 dark:text-slate-800"
              />
              <circle
                cx="120"
                cy="120"
                r="100"
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                strokeDasharray={2 * Math.PI * 100}
                strokeDashoffset={2 * Math.PI * 100 * (1 - progressPercent / 100)}
                strokeLinecap="round"
                className="text-indigo-600 transition-all duration-300"
              />
            </svg>

            {/* Inner Digits */}
            <div className="absolute flex flex-col items-center">
              <span className="font-mono text-5xl md:text-6xl font-black tracking-tight text-slate-900 dark:text-white">
                {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
              </span>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest mt-1">
                {mode === 'focus' ? 'Deep Focus' : 'Recovery Break'}
              </span>
            </div>
          </div>

          {/* Action Controls */}
          <div className="flex items-center gap-4">
            <button
              onClick={handleReset}
              className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 transition"
              title="Reset Timer"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            <button
              onClick={() => setIsActive(!isActive)}
              className={`px-8 py-4 rounded-2xl font-bold text-base shadow-lg transition active:scale-95 flex items-center gap-2 ${
                isActive
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/25'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
              }`}
            >
              {isActive ? (
                <>
                  <Pause className="w-5 h-5 fill-white" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-white" />
                  <span>Start Focus</span>
                </>
              )}
            </button>

            <button
              onClick={handleSkip}
              className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 transition"
              title="Skip Session"
            >
              <SkipForward className="w-5 h-5" />
            </button>
          </div>

          {/* Ambient Soundscapes bar */}
          <div className="w-full pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Music className="w-4 h-4 text-indigo-500" />
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Ambient Sound:
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleToggleAmbient('rain')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition ${
                    ambientSound === 'rain'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Rain 🌧️
                </button>
                <button
                  onClick={() => handleToggleAmbient('binaural')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition ${
                    ambientSound === 'binaural'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  40Hz Focus 🧠
                </button>
                <button
                  onClick={() => handleToggleAmbient('whitenoise')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition ${
                    ambientSound === 'whitenoise'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  White Noise 💨
                </button>
              </div>
            </div>

            {ambientSound !== 'none' && (
              <div className="flex items-center gap-2">
                <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="range"
                  min="0.05"
                  max="0.8"
                  step="0.05"
                  value={ambientVolume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="w-20 accent-indigo-600"
                />
              </div>
            )}
          </div>
        </div>

        {/* Focus Configuration & History Drawer (1 Col) */}
        <div className="space-y-6">
          {/* Link Task Card */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              Configure Session Task
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select from Scheduled Routine
              </label>
              <select
                value={linkedTitle}
                onChange={(e) => {
                  setLinkedTitle(e.target.value);
                  const matched = routineItems.find((r) => r.title === e.target.value);
                  if (matched) setLinkedCategory(matched.category);
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white"
              >
                {routineItems.map((item) => (
                  <option key={item.id} value={item.title}>
                    {item.title} ({item.category})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Custom Focus Duration (Minutes)
              </label>
              <div className="flex items-center gap-2">
                {[20, 25, 45, 60, 90].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => {
                      setCustomFocusMinutes(mins);
                      if (mode === 'focus') setSecondsRemaining(mins * 60);
                    }}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-bold font-mono transition ${
                      customFocusMinutes === mins
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Today's Focus History */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-500" />
                Recent Focus Sessions
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                {focusSessions.length} total
              </span>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {focusSessions.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">
                  No completed focus sessions yet. Finish a 25-minute sprint to record your first session!
                </p>
              ) : (
                focusSessions.slice(0, 6).map((s) => {
                  const meta = getCategoryMeta(s.category);
                  return (
                    <div
                      key={s.id}
                      className="p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="font-bold text-slate-800 dark:text-slate-200 truncate">
                          {s.taskTitle}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono">
                          {new Date(s.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {s.durationMinutes} mins
                        </p>
                      </div>
                      <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 shrink-0">
                        +{s.xpEarned} XP
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
