import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  Sparkles,
  AlertTriangle,
  Info,
  Trash2,
  Check,
  ShieldCheck,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { AppNotification, UserSettings } from '../types';
import { getNotificationPermissionState, requestNotificationPermission } from '../services/notifications';

interface NotificationsViewProps {
  notifications: AppNotification[];
  settings: UserSettings;
  onUpdateNotifications: (notifications: AppNotification[]) => void;
  onNavigateTab: (tab: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications,
  settings,
  onUpdateNotifications,
  onNavigateTab,
}) => {
  const [permissionState, setPermissionState] = useState<NotificationPermission>(() =>
    getNotificationPermissionState()
  );
  const [isRequesting, setIsRequesting] = useState(false);

  const handleRequestPermission = async () => {
    setIsRequesting(true);
    const result = await requestNotificationPermission();
    setPermissionState(result);
    setIsRequesting(false);
  };

  const handleMarkAllRead = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }));
    onUpdateNotifications(updated);
  };

  const handleClearAll = () => {
    if (confirm('Clear all notifications from history?')) {
      onUpdateNotifications([]);
    }
  };

  const handleDismiss = (id: string) => {
    onUpdateNotifications(notifications.filter((n) => n.id !== id));
  };

  const handleSnooze = (id: string, minutes: number) => {
    const snoozeUntil = new Date(Date.now() + minutes * 60000).toISOString();
    const updated = notifications.map((n) => (n.id === id ? { ...n, snoozedUntil: snoozeUntil, read: true } : n));
    onUpdateNotifications(updated);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-500" />
            Notification Center & Reminders
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Timetable reminders, upcoming milestones, and system push notification settings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {notifications.length > 0 && (
            <>
              <button
                onClick={handleMarkAllRead}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Mark All Read</span>
              </button>
              <button
                onClick={handleClearAll}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Permission Status Box */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div
            className={`p-3 rounded-2xl ${
              permissionState === 'granted'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 border border-emerald-200 dark:border-emerald-800'
                : 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 border border-amber-200 dark:border-amber-800'
            }`}
          >
            {permissionState === 'granted' ? (
              <ShieldCheck className="w-6 h-6" />
            ) : (
              <Bell className="w-6 h-6" />
            )}
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Browser Notification Permission:{' '}
              <span className="capitalize font-mono">
                {permissionState === 'granted' ? 'Enabled (Active)' : permissionState}
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {permissionState === 'granted'
                ? 'System alerts will trigger before scheduled routine items and focus timer completions.'
                : 'Allow notifications to receive lead-time alerts before your subjects begin.'}
            </p>
          </div>
        </div>

        {permissionState !== 'granted' && (
          <button
            onClick={handleRequestPermission}
            disabled={isRequesting}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95 shrink-0"
          >
            {isRequesting ? 'Requesting...' : 'Enable Browser Alerts'}
          </button>
        )}
      </div>

      {/* Notifications List */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
          Recent Notifications & Reminders ({notifications.length})
        </h3>

        {notifications.length === 0 ? (
          <div className="py-12 text-center text-slate-400 space-y-2">
            <Bell className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
            <p className="text-sm font-semibold">No active notifications</p>
            <p className="text-xs">Upcoming routine alerts and achievement unlocks will appear here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  item.read
                    ? 'bg-slate-50/50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800/60 opacity-80'
                    : 'bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-900 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5">
                    {item.type === 'achievement' ? (
                      <Sparkles className="w-4 h-4 text-amber-500" />
                    ) : (
                      <Clock className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {item.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      {item.message}
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(item.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                  {item.linkTab && (
                    <button
                      onClick={() => onNavigateTab(item.linkTab!)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 text-[11px] font-semibold"
                    >
                      Open
                    </button>
                  )}
                  <button
                    onClick={() => handleSnooze(item.id, 10)}
                    className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 text-[11px] font-medium"
                  >
                    Snooze 10m
                  </button>
                  <button
                    onClick={() => handleDismiss(item.id)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    title="Dismiss"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Honest Technical Limitation & Cloud FCM Guide (Prompt requirement #7) */}
      <div className="p-5 md:p-6 rounded-3xl bg-slate-100/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-indigo-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Background Push Notifications & Platform Limitations Guide
          </h3>
        </div>

        <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <p>
            • <strong>Active & Background Browser Tab:</strong> When LifeOS is installed as a PWA or open in a browser tab, all scheduled timetable reminders trigger on time with audio alerts and native system notifications.
          </p>
          <p>
            • <strong>When the Browser is Completely Closed (OS Restrictions):</strong> Web browsers strictly freeze client-side timers (`setInterval`) when closed to preserve device battery. To receive push alerts when the browser process is shut down:
          </p>
          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/60 space-y-1.5 font-mono text-[11px]">
            <p className="font-sans font-bold text-slate-800 dark:text-slate-200">
              Push Architecture Setup:
            </p>
            <p>1. Service Worker registration via `vite-plugin-pwa` handles incoming Web Push events.</p>
            <p>2. Firebase Cloud Messaging (FCM) credentials connect your device push token.</p>
            <p>3. A cloud cron trigger executes scheduled task reminders via Cloud Functions.</p>
          </div>
          <p>
            • <strong>iOS Safari Specifics:</strong> Apple requires iOS 16.4+ and requires the user to add LifeOS to the Home Screen via <em>"Add to Home Screen"</em> before WebKit allows Web Push notifications.
          </p>
        </div>
      </div>
    </div>
  );
};
