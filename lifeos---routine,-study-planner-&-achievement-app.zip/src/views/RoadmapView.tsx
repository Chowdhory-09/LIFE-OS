import React, { useState } from 'react';
import {
  Target,
  Plus,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Archive,
  Edit2,
  Trash2,
  TrendingUp,
  Layers,
  ChevronRight,
  Sparkles,
  Copy,
  AlertCircle,
} from 'lucide-react';
import { CategoryType, Milestone, MonthlyGoal, PriorityType } from '../types';
import { CATEGORIES_CONFIG, getCategoryMeta } from '../utils/categories';
import { getCurrentMonthString, getTodayDateString } from '../utils/schedule';

interface RoadmapViewProps {
  monthlyGoals: MonthlyGoal[];
  onSaveGoals: (goals: MonthlyGoal[]) => void;
  onMilestoneToggle: (goalId: string, milestoneId: string) => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({
  monthlyGoals,
  onSaveGoals,
  onMilestoneToggle,
}) => {
  const currentMonth = getCurrentMonthString();
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [showArchived, setShowArchived] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<MonthlyGoal | null>(null);

  // Form state
  const [goalTitle, setGoalTitle] = useState('');
  const [goalCategory, setGoalCategory] = useState<CategoryType>('Competitive Programming');
  const [goalDescription, setGoalDescription] = useState('');
  const [goalDeadline, setGoalDeadline] = useState(`${selectedMonth}-28`);
  const [goalPriority, setGoalPriority] = useState<PriorityType>('high');
  const [goalEstimatedHours, setGoalEstimatedHours] = useState(30);
  const [metricUnit, setMetricUnit] = useState('problems');
  const [metricTarget, setMetricTarget] = useState(60);
  const [metricCurrent, setMetricCurrent] = useState(0);

  // Milestones input state
  const [milestones, setMilestones] = useState<{ title: string; weekNumber: number; dueDate: string }[]>([
    { title: 'Week 1 Foundation Milestone', weekNumber: 1, dueDate: `${selectedMonth}-07` },
    { title: 'Week 2 Core Milestone', weekNumber: 2, dueDate: `${selectedMonth}-14` },
    { title: 'Week 3 Advanced Milestone', weekNumber: 3, dueDate: `${selectedMonth}-21` },
    { title: 'Week 4 Review & Final Test', weekNumber: 4, dueDate: `${selectedMonth}-28` },
  ]);

  // Filter goals
  const goalsForMonth = monthlyGoals.filter((g) => {
    if (showArchived) return g.isArchived;
    return g.month === selectedMonth && !g.isArchived;
  });

  // Calculate monthly stats
  const totalGoals = goalsForMonth.length;
  const allMilestones = goalsForMonth.flatMap((g) => g.milestones);
  const totalMilestones = allMilestones.length;
  const completedMilestonesCount = allMilestones.filter((m) => m.completed).length;
  const overallMonthPercent = totalMilestones > 0 ? Math.round((completedMilestonesCount / totalMilestones) * 100) : 0;

  const openCreateModal = () => {
    setEditingGoal(null);
    setGoalTitle('');
    setGoalCategory('Competitive Programming');
    setGoalDescription('');
    setGoalDeadline(`${selectedMonth}-28`);
    setGoalPriority('high');
    setGoalEstimatedHours(30);
    setMetricUnit('problems');
    setMetricTarget(60);
    setMetricCurrent(0);
    setMilestones([
      { title: 'Week 1 Milestone', weekNumber: 1, dueDate: `${selectedMonth}-07` },
      { title: 'Week 2 Milestone', weekNumber: 2, dueDate: `${selectedMonth}-14` },
      { title: 'Week 3 Milestone', weekNumber: 3, dueDate: `${selectedMonth}-21` },
      { title: 'Week 4 Final Milestone', weekNumber: 4, dueDate: `${selectedMonth}-28` },
    ]);
    setIsGoalModalOpen(true);
  };

  const openEditModal = (goal: MonthlyGoal) => {
    setEditingGoal(goal);
    setGoalTitle(goal.title);
    setGoalCategory(goal.category as CategoryType);
    setGoalDescription(goal.description);
    setGoalDeadline(goal.targetCompletionDate);
    setGoalPriority(goal.priority);
    setGoalEstimatedHours(goal.estimatedHours);
    setMetricUnit(goal.targetMetric?.unit || 'items');
    setMetricTarget(goal.targetMetric?.target || 10);
    setMetricCurrent(goal.targetMetric?.current || 0);
    setMilestones(
      goal.milestones.map((m) => ({
        title: m.title,
        weekNumber: m.weekNumber,
        dueDate: m.dueDate,
      }))
    );
    setIsGoalModalOpen(true);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;

    if (editingGoal) {
      const updated = monthlyGoals.map((g) => {
        if (g.id === editingGoal.id) {
          return {
            ...g,
            title: goalTitle.trim(),
            category: goalCategory,
            description: goalDescription.trim(),
            targetCompletionDate: goalDeadline,
            priority: goalPriority,
            estimatedHours: goalEstimatedHours,
            targetMetric: {
              current: metricCurrent,
              target: metricTarget,
              unit: metricUnit,
            },
            milestones: milestones.map((m, idx) => {
              const existing = editingGoal.milestones[idx];
              return {
                id: existing ? existing.id : 'm_' + Date.now() + '_' + idx,
                title: m.title,
                weekNumber: m.weekNumber,
                dueDate: m.dueDate,
                completed: existing ? existing.completed : false,
              };
            }),
          };
        }
        return g;
      });
      onSaveGoals(updated);
    } else {
      const newGoal: MonthlyGoal = {
        id: 'goal_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        month: selectedMonth,
        title: goalTitle.trim(),
        category: goalCategory,
        description: goalDescription.trim(),
        targetCompletionDate: goalDeadline,
        priority: goalPriority,
        estimatedHours: goalEstimatedHours,
        completedHours: 0,
        targetMetric: {
          current: metricCurrent,
          target: metricTarget,
          unit: metricUnit,
        },
        milestones: milestones.map((m, idx) => ({
          id: 'm_' + Date.now() + '_' + idx,
          title: m.title,
          weekNumber: m.weekNumber,
          dueDate: m.dueDate,
          completed: false,
        })),
        isArchived: false,
        createdAt: new Date().toISOString(),
      };
      onSaveGoals([...monthlyGoals, newGoal]);
    }

    setIsGoalModalOpen(false);
  };

  const handleToggleArchive = (goalId: string) => {
    const updated = monthlyGoals.map((g) => {
      if (g.id === goalId) {
        return { ...g, isArchived: !g.isArchived };
      }
      return g;
    });
    onSaveGoals(updated);
  };

  const handleDeleteGoal = (goalId: string) => {
    if (confirm('Delete this monthly roadmap goal and all associated milestones?')) {
      onSaveGoals(monthlyGoals.filter((g) => g.id !== goalId));
    }
  };

  const handleUpdateMetricProgress = (goalId: string, delta: number) => {
    const updated = monthlyGoals.map((g) => {
      if (g.id === goalId && g.targetMetric) {
        const nextVal = Math.max(0, Math.min(g.targetMetric.target, g.targetMetric.current + delta));
        return {
          ...g,
          targetMetric: {
            ...g.targetMetric,
            current: nextVal,
          },
        };
      }
      return g;
    });
    onSaveGoals(updated);
  };

  const handleCopyFromPreviousMonth = () => {
    // Generate previous month string
    const [y, m] = selectedMonth.split('-').map(Number);
    const prevDate = new Date(y, m - 2, 1);
    const prevMonthStr = `${prevDate.getFullYear()}-${(prevDate.getMonth() + 1).toString().padStart(2, '0')}`;
    const prevGoals = monthlyGoals.filter((g) => g.month === prevMonthStr);

    if (prevGoals.length === 0) {
      alert(`No goals found from previous month (${prevMonthStr}).`);
      return;
    }

    const copiedGoals: MonthlyGoal[] = prevGoals.map((g) => ({
      ...g,
      id: 'goal_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      month: selectedMonth,
      targetCompletionDate: `${selectedMonth}-28`,
      milestones: g.milestones.map((m, idx) => ({
        ...m,
        id: 'm_' + Date.now() + '_' + idx,
        completed: false,
        dueDate: `${selectedMonth}-${(idx * 7 + 7).toString().padStart(2, '0')}`,
      })),
      targetMetric: g.targetMetric ? { ...g.targetMetric, current: 0 } : undefined,
      completedHours: 0,
      isArchived: false,
      createdAt: new Date().toISOString(),
    }));

    onSaveGoals([...monthlyGoals, ...copiedGoals]);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-500" />
            Monthly Roadmap & Goal Planner
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Define high-level objectives, break them into weekly milestones, and link to daily routines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Month selector */}
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-mono font-semibold text-slate-800 dark:text-slate-200"
          />

          <button
            onClick={() => setShowArchived(!showArchived)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition ${
              showArchived
                ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
            }`}
          >
            <Archive className="w-3.5 h-3.5 inline mr-1" />
            {showArchived ? 'Active Goals' : 'Archived'}
          </button>

          <button
            onClick={openCreateModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>New Monthly Goal</span>
          </button>
        </div>
      </div>

      {/* Monthly Summary Banner */}
      <div className="p-5 md:p-6 rounded-3xl bg-gradient-to-r from-indigo-900 via-slate-900 to-violet-950 text-white shadow-xl border border-indigo-800/40 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
            {selectedMonth} Roadmap Progress
          </span>
          <h3 className="text-2xl font-extrabold tracking-tight">
            {overallMonthPercent}% Completed ({completedMilestonesCount}/{totalMilestones} Milestones)
          </h3>
          <p className="text-xs text-slate-300 max-w-lg">
            Consistent progress across your study modules directly unlocks monthly achievement badges.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-24 text-right">
            <span className="text-xs text-slate-300 block">Total Goals</span>
            <span className="text-xl font-bold font-mono">{totalGoals}</span>
          </div>
          <button
            onClick={handleCopyFromPreviousMonth}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md border border-white/10 transition"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Prev Month</span>
          </button>
        </div>
      </div>

      {/* Goals Grid */}
      {goalsForMonth.length === 0 ? (
        <div className="py-16 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3">
          <Target className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            {showArchived ? 'No archived goals found' : `No goals set for ${selectedMonth}`}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Set ambitious monthly targets like solving 60 CP problems, building a full-stack project, or completing IELTS units.
          </p>
          <div className="pt-2 flex justify-center gap-2">
            <button
              onClick={openCreateModal}
              className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-sm hover:bg-indigo-500"
            >
              Add First Goal
            </button>
            <button
              onClick={handleCopyFromPreviousMonth}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300"
            >
              Copy From Previous Month
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {goalsForMonth.map((goal) => {
            const meta = getCategoryMeta(goal.category);
            const completedCount = goal.milestones.filter((m) => m.completed).length;
            const totalCount = goal.milestones.length;
            const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
            const isOverdue = goal.targetCompletionDate < getTodayDateString() && percent < 100;

            return (
              <div
                key={goal.id}
                className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm flex flex-col justify-between space-y-5 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition"
              >
                {/* Header */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span
                      className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold border ${meta.bgLight} ${meta.textLight} ${meta.bgDark} ${meta.textDark} ${meta.borderColor}`}
                    >
                      {meta.label}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {isOverdue && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 px-2 py-0.5 rounded-full border border-red-200 dark:border-red-800">
                          <AlertCircle className="w-3 h-3" /> Overdue
                        </span>
                      )}
                      <button
                        onClick={() => openEditModal(goal)}
                        className="p-1 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="Edit Goal"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleToggleArchive(goal.id)}
                        className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title={goal.isArchived ? 'Restore' : 'Archive'}
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {goal.title}
                  </h3>

                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {goal.description}
                  </p>
                </div>

                {/* Metric Counter if applicable */}
                {goal.targetMetric && (
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Metric Tracker
                      </span>
                      <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                        {goal.targetMetric.current} / {goal.targetMetric.target} {goal.targetMetric.unit}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleUpdateMetricProgress(goal.id, -1)}
                        className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100"
                      >
                        -1
                      </button>
                      <button
                        onClick={() => handleUpdateMetricProgress(goal.id, 1)}
                        className="w-7 h-7 rounded-lg bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500"
                      >
                        +1
                      </button>
                    </div>
                  </div>
                )}

                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-300">
                      Milestones ({completedCount}/{totalCount})
                    </span>
                    <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {percent}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                {/* Weekly Milestones Checklist */}
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    Weekly Breakdown
                  </span>
                  {goal.milestones.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-50/50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/80 text-xs hover:bg-slate-100/50 transition"
                    >
                      <button
                        onClick={() => onMilestoneToggle(goal.id, m.id)}
                        className="flex items-center gap-2 text-left flex-1 min-w-0"
                      >
                        {m.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 fill-emerald-500/20" />
                        ) : (
                          <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                        <span className={`truncate font-medium ${m.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                          {m.title}
                        </span>
                      </button>

                      <span className="text-[10px] text-slate-400 font-mono shrink-0 pl-2">
                        Due {m.dueDate.substring(5)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Footer Metadata */}
                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3" />
                    Target: {goal.targetCompletionDate}
                  </span>
                  <span>Est. {goal.estimatedHours}h</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Goal Modal */}
      {isGoalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 my-8">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              {editingGoal ? 'Edit Monthly Roadmap Goal' : `New Goal for ${selectedMonth}`}
            </h3>

            <form onSubmit={handleSaveGoal} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Goal Title *
                </label>
                <input
                  type="text"
                  required
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  placeholder="e.g. Solve 60 CP Problems or Pass IELTS Mock"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={goalCategory}
                    onChange={(e) => setGoalCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white"
                  >
                    {Object.keys(CATEGORIES_CONFIG).map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={goalPriority}
                    onChange={(e) => setGoalPriority(e.target.value as PriorityType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target Completion Date
                  </label>
                  <input
                    type="date"
                    required
                    value={goalDeadline}
                    onChange={(e) => setGoalDeadline(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Estimated Study Hours
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={goalEstimatedHours}
                    onChange={(e) => setGoalEstimatedHours(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Target Metric */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2">
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                  Numerical Target Metric
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400">Current</label>
                    <input
                      type="number"
                      min="0"
                      value={metricCurrent}
                      onChange={(e) => setMetricCurrent(parseInt(e.target.value, 10) || 0)}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Target</label>
                    <input
                      type="number"
                      min="1"
                      value={metricTarget}
                      onChange={(e) => setMetricTarget(parseInt(e.target.value, 10) || 1)}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Unit</label>
                    <input
                      type="text"
                      value={metricUnit}
                      onChange={(e) => setMetricUnit(e.target.value)}
                      placeholder="e.g. problems, hours"
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Milestones */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Weekly Milestones Breakdown (4 Weeks)
                </label>
                {milestones.map((m, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400 w-14 shrink-0">Wk {m.weekNumber}</span>
                    <input
                      type="text"
                      value={m.title}
                      onChange={(e) => {
                        const copy = [...milestones];
                        copy[idx].title = e.target.value;
                        setMilestones(copy);
                      }}
                      className="flex-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                    />
                    <input
                      type="date"
                      value={m.dueDate}
                      onChange={(e) => {
                        const copy = [...milestones];
                        copy[idx].dueDate = e.target.value;
                        setMilestones(copy);
                      }}
                      className="w-28 px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px]"
                    />
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsGoalModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30"
                >
                  Save Roadmap Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
