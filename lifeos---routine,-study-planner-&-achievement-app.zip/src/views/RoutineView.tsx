import React, { useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  Check,
  ChevronDown,
  Clock,
  Copy,
  Edit2,
  List,
  MoreVertical,
  Plus,
  Repeat,
  Trash2,
  ArrowUpDown,
  MoveUp,
  MoveDown,
  FileCheck,
  Sparkles,
  Link as LinkIcon,
  Bell,
} from 'lucide-react';
import {
  CategoryType,
  MonthlyGoal,
  PriorityType,
  RoutineItem,
  ScheduleConflict,
  UserSettings,
} from '../types';
import { CATEGORIES_CONFIG, getCategoryMeta } from '../utils/categories';
import {
  calculateDurationMinutes,
  DAY_NAMES,
  detectConflictsForDay,
  formatDuration,
  formatTimeDisplay,
  minutesToTime,
  SHORT_DAY_NAMES,
  timeToMinutes,
} from '../utils/schedule';

interface RoutineViewProps {
  routineItems: RoutineItem[];
  monthlyGoals: MonthlyGoal[];
  settings: UserSettings;
  onSaveRoutine: (items: RoutineItem[]) => void;
  onStartFocusOnTask: (taskTitle: string, category: string, routineId?: string) => void;
}

export const RoutineView: React.FC<RoutineViewProps> = ({
  routineItems,
  monthlyGoals,
  settings,
  onSaveRoutine,
  onStartFocusOnTask,
}) => {
  const [selectedDay, setSelectedDay] = useState<number>(() => {
    const today = new Date().getDay();
    // if Monday starts week (1), default to today
    return today;
  });

  const [viewMode, setViewMode] = useState<'timeline' | 'list'>('timeline');
  const [editingItem, setEditingItem] = useState<RoutineItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showCopyModal, setShowCopyModal] = useState(false);
  const [copySourceDay, setCopySourceDay] = useState<number>(selectedDay);
  const [copyTargetDays, setCopyTargetDays] = useState<number[]>([]);

  // Form State for Add / Edit
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<CategoryType>('University');
  const [formCustomCategory, setFormCustomCategory] = useState('');
  const [formStartTime, setFormStartTime] = useState('09:00');
  const [formEndTime, setFormEndTime] = useState('10:30');
  const [formDaysOfWeek, setFormDaysOfWeek] = useState<number[]>([1, 2, 3, 4, 5]);
  const [formPriority, setFormPriority] = useState<PriorityType>('medium');
  const [formReminderMinutes, setFormReminderMinutes] = useState(10);
  const [formReminderEnabled, setFormReminderEnabled] = useState(true);
  const [formDescription, setFormDescription] = useState('');
  const [formLinkedGoalId, setFormLinkedGoalId] = useState('');

  // Conflict detection for current day
  const conflicts = detectConflictsForDay(routineItems, selectedDay);

  // Filter items for selected day
  const dayItems = routineItems
    .filter((item) => item.daysOfWeek.includes(selectedDay))
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  const openCreateModal = () => {
    setEditingItem(null);
    setFormTitle('');
    setFormCategory('University');
    setFormCustomCategory('');
    setFormStartTime('09:00');
    setFormEndTime('10:30');
    setFormDaysOfWeek([selectedDay]);
    setFormPriority('medium');
    setFormReminderMinutes(settings.defaultReminderMinutes || 10);
    setFormReminderEnabled(true);
    setFormDescription('');
    setFormLinkedGoalId('');
    setIsModalOpen(true);
  };

  const openEditModal = (item: RoutineItem) => {
    setEditingItem(item);
    setFormTitle(item.title);
    setFormCategory(item.category);
    setFormCustomCategory(item.customCategoryName || '');
    setFormStartTime(item.startTime);
    setFormEndTime(item.endTime);
    setFormDaysOfWeek([...item.daysOfWeek]);
    setFormPriority(item.priority);
    setFormReminderMinutes(item.reminderMinutes);
    setFormReminderEnabled(item.reminderEnabled);
    setFormDescription(item.description || '');
    setFormLinkedGoalId(item.linkedGoalId || '');
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const duration = calculateDurationMinutes(formStartTime, formEndTime);

    if (editingItem) {
      // Update
      const updated = routineItems.map((item) => {
        if (item.id === editingItem.id) {
          return {
            ...item,
            title: formTitle.trim(),
            category: formCategory,
            customCategoryName: formCategory === 'Custom' ? formCustomCategory.trim() : undefined,
            startTime: formStartTime,
            endTime: formEndTime,
            daysOfWeek: formDaysOfWeek.length > 0 ? formDaysOfWeek : [selectedDay],
            priority: formPriority,
            reminderMinutes: formReminderMinutes,
            reminderEnabled: formReminderEnabled,
            targetDurationMinutes: duration,
            description: formDescription.trim(),
            linkedGoalId: formLinkedGoalId || undefined,
          };
        }
        return item;
      });
      onSaveRoutine(updated);
    } else {
      // Create new
      const newItem: RoutineItem = {
        id: 'routine_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        title: formTitle.trim(),
        category: formCategory,
        customCategoryName: formCategory === 'Custom' ? formCustomCategory.trim() : undefined,
        startTime: formStartTime,
        endTime: formEndTime,
        daysOfWeek: formDaysOfWeek.length > 0 ? formDaysOfWeek : [selectedDay],
        isRecurring: true,
        priority: formPriority,
        reminderMinutes: formReminderMinutes,
        reminderEnabled: formReminderEnabled,
        targetDurationMinutes: duration,
        description: formDescription.trim(),
        linkedGoalId: formLinkedGoalId || undefined,
        orderIndex: routineItems.length,
      };
      onSaveRoutine([...routineItems, newItem]);
    }

    setIsModalOpen(false);
  };

  const handleDeleteItem = (id: string) => {
    if (confirm('Are you sure you want to remove this routine item?')) {
      const filtered = routineItems.filter((i) => i.id !== id);
      onSaveRoutine(filtered);
    }
  };

  const handleDuplicateItem = (item: RoutineItem) => {
    const startM = timeToMinutes(item.startTime);
    const endM = timeToMinutes(item.endTime);
    const duration = calculateDurationMinutes(item.startTime, item.endTime);
    // shift 30 mins
    const newStart = minutesToTime(endM + 15);
    const newEnd = minutesToTime(endM + 15 + duration);

    const duplicated: RoutineItem = {
      ...item,
      id: 'routine_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: `${item.title} (Copy)`,
      startTime: newStart,
      endTime: newEnd,
      orderIndex: routineItems.length,
    };
    onSaveRoutine([...routineItems, duplicated]);
  };

  const handleMoveOrder = (item: RoutineItem, direction: 'up' | 'down') => {
    const idx = dayItems.findIndex((i) => i.id === item.id);
    if (direction === 'up' && idx > 0) {
      const prev = dayItems[idx - 1];
      // swap times
      const tempStart = item.startTime;
      const tempEnd = item.endTime;
      const updated = routineItems.map((r) => {
        if (r.id === item.id) return { ...r, startTime: prev.startTime, endTime: prev.endTime };
        if (r.id === prev.id) return { ...r, startTime: tempStart, endTime: tempEnd };
        return r;
      });
      onSaveRoutine(updated);
    } else if (direction === 'down' && idx < dayItems.length - 1) {
      const next = dayItems[idx + 1];
      const tempStart = item.startTime;
      const tempEnd = item.endTime;
      const updated = routineItems.map((r) => {
        if (r.id === item.id) return { ...r, startTime: next.startTime, endTime: next.endTime };
        if (r.id === next.id) return { ...r, startTime: tempStart, endTime: tempEnd };
        return r;
      });
      onSaveRoutine(updated);
    }
  };

  // Auto-resolve conflict helper
  const handleAutoResolveConflict = (conflict: ScheduleConflict) => {
    const aEndMinutes = timeToMinutes(conflict.itemA.startTime) + calculateDurationMinutes(conflict.itemA.startTime, conflict.itemA.endTime);
    const bDuration = calculateDurationMinutes(conflict.itemB.startTime, conflict.itemB.endTime);
    const newBStart = minutesToTime(aEndMinutes + 10);
    const newBEnd = minutesToTime(aEndMinutes + 10 + bDuration);

    const updated = routineItems.map((item) => {
      if (item.id === conflict.itemB.id) {
        return {
          ...item,
          startTime: newBStart,
          endTime: newBEnd,
        };
      }
      return item;
    });
    onSaveRoutine(updated);
  };

  // Copy routine between days
  const handleExecuteCopy = () => {
    if (copyTargetDays.length === 0) return;
    const sourceItems = routineItems.filter((i) => i.daysOfWeek.includes(copySourceDay));

    const updated = routineItems.map((item) => {
      if (item.daysOfWeek.includes(copySourceDay)) {
        // Add target days to this item
        const combined = Array.from(new Set([...item.daysOfWeek, ...copyTargetDays]));
        return { ...item, daysOfWeek: combined };
      }
      return item;
    });

    onSaveRoutine(updated);
    setShowCopyModal(false);
    setCopyTargetDays([]);
  };

  const totalDayMinutes = dayItems.reduce((acc, item) => {
    return acc + calculateDurationMinutes(item.startTime, item.endTime);
  }, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Day Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-500" />
            Daily Routine & Timetable
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Design fixed time slots, prevent overlaps, and configure daily recurring subjects.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setCopySourceDay(selectedDay);
              setCopyTargetDays([]);
              setShowCopyModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-indigo-400 transition"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Schedule</span>
          </button>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Routine Item</span>
          </button>
        </div>
      </div>

      {/* Weekday Selector Pills */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5">
          {SHORT_DAY_NAMES.map((shortName, idx) => {
            const isSelected = selectedDay === idx;
            const countForDay = routineItems.filter((i) => i.daysOfWeek.includes(idx)).length;
            const hasConflict = detectConflictsForDay(routineItems, idx).length > 0;

            return (
              <button
                key={shortName}
                onClick={() => setSelectedDay(idx)}
                className={`relative flex flex-col items-center px-3.5 py-2 rounded-2xl text-xs font-semibold transition ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25 scale-105'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50'
                }`}
              >
                <span>{shortName}</span>
                <span
                  className={`text-[10px] mt-0.5 ${
                    isSelected ? 'text-indigo-200' : 'text-slate-400'
                  }`}
                >
                  {countForDay} {countForDay === 1 ? 'task' : 'tasks'}
                </span>
                {hasConflict && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5 rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-900" />
                )}
              </button>
            );
          })}
        </div>

        {/* View Switcher */}
        <div className="hidden sm:flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 text-xs">
          <button
            onClick={() => setViewMode('timeline')}
            className={`px-3 py-1 rounded-lg font-medium transition ${
              viewMode === 'timeline'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Timeline View
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1 rounded-lg font-medium transition ${
              viewMode === 'list'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            List View
          </button>
        </div>
      </div>

      {/* Conflict Warning Alert Box */}
      {conflicts.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 space-y-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <h4 className="text-sm font-bold">
              Schedule Conflict Detected ({conflicts.length} overlapping slot{conflicts.length > 1 ? 's' : ''})
            </h4>
          </div>
          <div className="space-y-1.5 pl-7 text-xs">
            {conflicts.map((c, i) => (
              <div key={i} className="flex flex-wrap items-center justify-between gap-2">
                <span>
                  <strong>"{c.itemA.title}"</strong> ({formatTimeDisplay(c.itemA.startTime, settings.timeFormat)} - {formatTimeDisplay(c.itemA.endTime, settings.timeFormat)}) overlaps with <strong>"{c.itemB.title}"</strong> ({formatTimeDisplay(c.itemB.startTime, settings.timeFormat)} - {formatTimeDisplay(c.itemB.endTime, settings.timeFormat)}) by {c.overlapMinutes} mins.
                </span>
                <button
                  onClick={() => handleAutoResolveConflict(c)}
                  className="px-2.5 py-1 rounded-lg bg-amber-600 text-white font-semibold hover:bg-amber-500 transition text-[11px]"
                >
                  Auto-Resolve Time
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Routine Content */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {DAY_NAMES[selectedDay]} Schedule
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Total planned time: {formatDuration(totalDayMinutes)} • {dayItems.length} activities
            </p>
          </div>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-700 dark:text-slate-200 hover:text-indigo-600 text-xs font-semibold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Slot</span>
          </button>
        </div>

        {dayItems.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
              <Clock className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              No routine activities scheduled for {DAY_NAMES[selectedDay]} yet.
            </p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Add your university classes, coding blocks, IELTS study sessions, or copy from another day.
            </p>
            <div className="pt-2 flex justify-center gap-2">
              <button
                onClick={openCreateModal}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-sm hover:bg-indigo-500 transition"
              >
                Create New Activity
              </button>
              <button
                onClick={() => {
                  setCopySourceDay(selectedDay === 1 ? 0 : 1);
                  setCopyTargetDays([selectedDay]);
                  setShowCopyModal(true);
                }}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50"
              >
                Copy from Another Day
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {dayItems.map((item, idx) => {
              const meta = getCategoryMeta(item.category);
              const duration = calculateDurationMinutes(item.startTime, item.endTime);
              const linkedGoal = monthlyGoals.find((g) => g.id === item.linkedGoalId);

              return (
                <div
                  key={item.id}
                  className="group relative flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-indigo-400 dark:hover:border-indigo-500/50 shadow-xs transition"
                >
                  <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                    {/* Time indicator pill */}
                    <div className="w-28 shrink-0 space-y-0.5">
                      <div className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                        {formatTimeDisplay(item.startTime, settings.timeFormat)}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        to {formatTimeDisplay(item.endTime, settings.timeFormat)}
                      </div>
                      <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">
                        {formatDuration(duration)}
                      </div>
                    </div>

                    {/* Color bar */}
                    <div
                      className="hidden sm:block w-1.5 self-stretch rounded-full shrink-0"
                      style={{ backgroundColor: meta.color }}
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {item.title}
                        </h4>

                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${meta.bgLight} ${meta.textLight} ${meta.bgDark} ${meta.textDark} ${meta.borderColor}`}
                        >
                          {meta.label}
                        </span>

                        {item.priority === 'high' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800">
                            HIGH
                          </span>
                        )}

                        {linkedGoal && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                            <LinkIcon className="w-3 h-3" />
                            {linkedGoal.title.substring(0, 24)}...
                          </span>
                        )}
                      </div>

                      {item.description && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                          {item.description}
                        </p>
                      )}

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                        {item.reminderEnabled && (
                          <span className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                            <Bell className="w-3 h-3 text-indigo-500" />
                            {item.reminderMinutes}m reminder
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Repeat className="w-3 h-3" />
                          {item.daysOfWeek.length === 7
                            ? 'Daily'
                            : item.daysOfWeek.length === 5 && !item.daysOfWeek.includes(0) && !item.daysOfWeek.includes(6)
                            ? 'Weekdays'
                            : item.daysOfWeek.map((d) => SHORT_DAY_NAMES[d]).join(', ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right actions: Reorder, Focus, Duplicate, Edit, Delete */}
                  <div className="mt-3 sm:mt-0 flex items-center justify-end gap-1 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                    <button
                      onClick={() => handleMoveOrder(item, 'up')}
                      disabled={idx === 0}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                      title="Move Up"
                    >
                      <MoveUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleMoveOrder(item, 'down')}
                      disabled={idx === dayItems.length - 1}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                      title="Move Down"
                    >
                      <MoveDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDuplicateItem(item)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                      title="Duplicate"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => openEditModal(item)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add / Edit Routine Item Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 my-8">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              {editingItem ? 'Edit Routine Item' : 'New Routine Activity'}
            </h3>

            <form onSubmit={handleSaveModal} className="mt-4 space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subject / Task Name *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Competitive Programming DP Practice"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  >
                    {Object.keys(CATEGORIES_CONFIG).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as PriorityType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="low">Low (15 XP)</option>
                    <option value="medium">Medium (30 XP)</option>
                    <option value="high">High (50 XP)</option>
                  </select>
                </div>
              </div>

              {/* Custom Category Input if Custom is selected */}
              {formCategory === 'Custom' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Custom Category Label
                  </label>
                  <input
                    type="text"
                    value={formCustomCategory}
                    onChange={(e) => setFormCustomCategory(e.target.value)}
                    placeholder="e.g. Robotics Lab, French Class"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>
              )}

              {/* Times */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    required
                    value={formStartTime}
                    onChange={(e) => setFormStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    required
                    value={formEndTime}
                    onChange={(e) => setFormEndTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                Calculated Duration: {formatDuration(calculateDurationMinutes(formStartTime, formEndTime))}
              </div>

              {/* Recurring Weekdays */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Recurring Days
                  </label>
                  <div className="flex items-center gap-1.5 text-[10px]">
                    <button
                      type="button"
                      onClick={() => setFormDaysOfWeek([1, 2, 3, 4, 5])}
                      className="text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Weekdays
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => setFormDaysOfWeek([0, 6])}
                      className="text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Weekends
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => setFormDaysOfWeek([0, 1, 2, 3, 4, 5, 6])}
                      className="text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Every Day
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-7 gap-1.5">
                  {SHORT_DAY_NAMES.map((d, idx) => {
                    const active = formDaysOfWeek.includes(idx);
                    return (
                      <button
                        key={d}
                        type="button"
                        onClick={() => {
                          if (active) {
                            setFormDaysOfWeek(formDaysOfWeek.filter((day) => day !== idx));
                          } else {
                            setFormDaysOfWeek([...formDaysOfWeek, idx]);
                          }
                        }}
                        className={`py-1.5 rounded-xl text-xs font-bold transition ${
                          active
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                        }`}
                      >
                        {d}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Reminders */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-indigo-500" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Enable Reminder
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    disabled={!formReminderEnabled}
                    value={formReminderMinutes}
                    onChange={(e) => setFormReminderMinutes(parseInt(e.target.value, 10))}
                    className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium disabled:opacity-50"
                  >
                    <option value={5}>5 mins before</option>
                    <option value={10}>10 mins before</option>
                    <option value={15}>15 mins before</option>
                    <option value={30}>30 mins before</option>
                  </select>
                  <input
                    type="checkbox"
                    checked={formReminderEnabled}
                    onChange={(e) => setFormReminderEnabled(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded"
                  />
                </div>
              </div>

              {/* Link to Monthly Goal */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Link to Monthly Roadmap Goal (Optional)
                </label>
                <select
                  value={formLinkedGoalId}
                  onChange={(e) => setFormLinkedGoalId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                >
                  <option value="">-- No linked goal --</option>
                  {monthlyGoals.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.title} ({g.category})
                    </option>
                  ))}
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Description & Notes
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Key topics, lecture links, problem sets..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30"
                >
                  {editingItem ? 'Save Changes' : 'Create Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Copy Schedule Modal */}
      {showCopyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              Copy Routine Across Days
            </h3>

            <div className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Copy from:
                </label>
                <select
                  value={copySourceDay}
                  onChange={(e) => setCopySourceDay(parseInt(e.target.value, 10))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white"
                >
                  {DAY_NAMES.map((name, i) => (
                    <option key={name} value={i}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Select destination days:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {DAY_NAMES.map((name, i) => {
                    if (i === copySourceDay) return null;
                    const isChecked = copyTargetDays.includes(i);
                    return (
                      <label
                        key={name}
                        className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer transition ${
                          isChecked
                            ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-semibold'
                            : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setCopyTargetDays([...copyTargetDays, i]);
                            } else {
                              setCopyTargetDays(copyTargetDays.filter((d) => d !== i));
                            }
                          }}
                          className="rounded text-indigo-600"
                        />
                        <span>{name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCopyModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={copyTargetDays.length === 0}
                  onClick={handleExecuteCopy}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 disabled:opacity-40"
                >
                  Apply Copy
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
