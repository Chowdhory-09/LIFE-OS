import React, { useState, useEffect } from 'react';
import {
  Settings,
  User as UserIcon,
  Clock,
  Bell,
  Sliders,
  Shield,
  Download,
  Upload,
  RefreshCw,
  Database,
  Check,
  Moon,
  Sun,
  Laptop,
} from 'lucide-react';
import { UserSettings } from '../types';
import { StorageService } from '../services/storage';
import { applyTheme } from '../utils/theme';

import { User } from 'firebase/auth';
import { SyncStatus } from '../services/cloudSync';
import { LogIn, LogOut, Cloud, CheckCircle2 } from 'lucide-react';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: UserSettings) => void;
  onReloadAllData: () => void;
  currentUser?: User | null;
  syncStatus?: SyncStatus;
  onOpenAuthModal?: () => void;
  onManualSync?: () => void;
  onSignOut?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onReloadAllData,
  currentUser = null,
  syncStatus = 'local_only',
  onOpenAuthModal,
  onManualSync,
  onSignOut,
}) => {
  const [form, setForm] = useState<UserSettings>(settings);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  useEffect(() => {
    setForm(settings);
  }, [settings]);

  const handleChange = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'system') => {
    const updated = { ...form, theme: newTheme };
    setForm(updated);
    applyTheme(newTheme);
    onUpdateSettings(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    applyTheme(form.theme);
    onUpdateSettings(form);
    StorageService.saveSettings(form);

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const success = StorageService.importFullBackupJSON(content);
        if (success) {
          setImportStatus('Backup successfully restored! Refreshing application data...');
          setTimeout(() => {
            onReloadAllData();
            setImportStatus(null);
          }, 1500);
        } else {
          setImportStatus('Error: Invalid backup file format.');
        }
      } catch {
        setImportStatus('Error: Could not read backup file.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (
      confirm(
        'Are you sure you want to reset all LifeOS data to factory defaults? All customized routines, tasks, and achievements will be restored to original samples.'
      )
    ) {
      StorageService.resetToDefault();
      onReloadAllData();
      alert('Application reset to factory defaults.');
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-500" />
            Settings & Personalization
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Configure schedule preferences, Pomodoro durations, notifications, and cloud sync.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-semibold animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>Preferences Saved!</span>
          </div>
        )}
      </div>

      {/* Google Account & Cloud Sync Section */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Google Account & Cloud Synchronization
            </h3>
          </div>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
            currentUser
              ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
          }`}>
            {currentUser ? 'Cloud Synced' : 'Guest / Local Storage'}
          </span>
        </div>

        {currentUser ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center gap-3.5">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || ''}
                  className="w-12 h-12 rounded-full ring-2 ring-indigo-500/30 object-cover shadow-sm"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white font-bold text-sm flex items-center justify-center">
                  {(currentUser.displayName || 'U').charAt(0)}
                </div>
              )}
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {currentUser.displayName}
                  </h4>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  {currentUser.email}
                </p>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                  UID: {currentUser.uid.substring(0, 16)}...
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {onManualSync && (
                <button
                  type="button"
                  onClick={onManualSync}
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-indigo-400 transition"
                >
                  Sync Now
                </button>
              )}
              {onSignOut && (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="px-3.5 py-2 rounded-xl bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400 border border-red-200 dark:border-red-800 text-xs font-semibold hover:bg-red-100 transition"
                >
                  Sign Out
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50/60 to-purple-50/60 dark:from-indigo-950/30 dark:to-purple-950/30 border border-indigo-100 dark:border-indigo-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                You are currently using LifeOS in Guest Mode (Offline)
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 max-w-lg">
                Your data is stored in your local browser storage. Sign in with Google to enable cross-device cloud synchronization across your phone, tablet, and laptop.
              </p>
            </div>
            {onOpenAuthModal && (
              <button
                type="button"
                onClick={onOpenAuthModal}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/25 transition active:scale-95 shrink-0"
              >
                <LogIn className="w-4 h-4" />
                <span>Continue with Google</span>
              </button>
            )}
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* User Profile & Regional */}
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
            <UserIcon className="w-4 h-4 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              User Profile & Time Settings
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Display Name
              </label>
              <input
                type="text"
                value={form.displayName}
                onChange={(e) => handleChange('displayName', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Timezone
              </label>
              <input
                type="text"
                value={form.timezone}
                onChange={(e) => handleChange('timezone', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Clock Format
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleChange('timeFormat', '12h')}
                  className={`flex-1 py-2 rounded-xl border text-xs font-semibold transition ${
                    form.timeFormat === '12h'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  12-Hour (AM/PM)
                </button>
                <button
                  type="button"
                  onClick={() => handleChange('timeFormat', '24h')}
                  className={`flex-1 py-2 rounded-xl border text-xs font-semibold transition ${
                    form.timeFormat === '24h'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  24-Hour (Military)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Week Starts On
              </label>
              <select
                value={form.weekStartsOn}
                onChange={(e) => handleChange('weekStartsOn', parseInt(e.target.value, 10) as 0 | 1)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white"
              >
                <option value={1}>Monday (ISO Standard)</option>
                <option value={0}>Sunday</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                App Theme
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleThemeChange('light')}
                  className={`py-2 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                    form.theme === 'light'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 dark:border-indigo-500 shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" /> Light
                </button>
                <button
                  type="button"
                  onClick={() => handleThemeChange('dark')}
                  className={`py-2 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                    form.theme === 'dark'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 dark:border-indigo-500 shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" /> Dark
                </button>
                <button
                  type="button"
                  onClick={() => handleThemeChange('system')}
                  className={`py-2 px-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                    form.theme === 'system'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 dark:border-indigo-500 shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Laptop className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" /> System
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Study Targets & Focus Timer Defaults */}
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
            <Sliders className="w-4 h-4 text-purple-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Study Targets & Focus Timer Defaults
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Daily Study Target (Hours)
              </label>
              <input
                type="number"
                min="1"
                max="24"
                value={form.dailyProductivityTargetHours}
                onChange={(e) => handleChange('dailyProductivityTargetHours', parseInt(e.target.value, 10) || 6)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Weekly Study Target (Hours)
              </label>
              <input
                type="number"
                min="1"
                max="168"
                value={form.weeklyStudyTargetHours}
                onChange={(e) => handleChange('weeklyStudyTargetHours', parseInt(e.target.value, 10) || 35)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                Default Focus (min)
              </label>
              <input
                type="number"
                min="5"
                max="120"
                value={form.defaultFocusDuration}
                onChange={(e) => handleChange('defaultFocusDuration', parseInt(e.target.value, 10) || 25)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                Short Break (min)
              </label>
              <input
                type="number"
                min="1"
                max="30"
                value={form.defaultShortBreak}
                onChange={(e) => handleChange('defaultShortBreak', parseInt(e.target.value, 10) || 5)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                Long Break (min)
              </label>
              <input
                type="number"
                min="5"
                max="60"
                value={form.defaultLongBreak}
                onChange={(e) => handleChange('defaultLongBreak', parseInt(e.target.value, 10) || 15)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
              />
            </div>
          </div>
        </div>

        {/* Alerts & Sound Settings */}
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
            <Bell className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Notifications & Sound Alerts
            </h3>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                  Enable Timetable Reminders
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Trigger notifications before routine activities start
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.notificationsEnabled}
                onChange={(e) => handleChange('notificationsEnabled', e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                  Sound Effects & Chimes
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Harmonic audio feedback on task completion and timer expiry
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.soundAlerts}
                onChange={(e) => handleChange('soundAlerts', e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                  Auto-Detect Schedule Conflicts
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Highlight overlapping routine activities and suggest fixes
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.autoDetectConflicts}
                onChange={(e) => handleChange('autoDetectConflicts', e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>
          </div>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            Save All Preferences
          </button>
        </div>
      </form>

      {/* Backup, Restore & Reset Section */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <Database className="w-4 h-4 text-cyan-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Data Storage, Backup & Synchronization
          </h3>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          All your routines, task logs, goals, and achievements are persistently stored in your browser using IndexedDB and LocalStorage with full offline resilience.
        </p>

        {importStatus && (
          <div className="p-3 rounded-xl bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 text-xs font-semibold">
            {importStatus}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <label className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer transition">
            <Upload className="w-3.5 h-3.5" />
            <span>Restore Backup JSON</span>
            <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
          </label>

          <button
            type="button"
            onClick={handleResetData}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400 border border-red-200 dark:border-red-800 text-xs font-semibold hover:bg-red-100 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset to Factory Defaults</span>
          </button>
        </div>
      </div>
    </div>
  );
};
