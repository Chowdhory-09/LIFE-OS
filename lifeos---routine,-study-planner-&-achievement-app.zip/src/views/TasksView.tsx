import React, { useState } from 'react';
import {
  CheckSquare,
  CheckCircle2,
  Circle,
  Clock,
  Plus,
  RotateCcw,
  SkipForward,
  Calendar,
  Filter,
  Search,
  AlertCircle,
  Tag,
  ArrowRight,
} from 'lucide-react';
import { CategoryType, PriorityType, RoutineItem, TaskRecord, UserSettings } from '../types';
import { CATEGORIES_CONFIG, getCategoryMeta } from '../utils/categories';
import { formatTimeDisplay, getTodayDateString } from '../utils/schedule';

interface TasksViewProps {
  taskRecords: TaskRecord[];
  routineItems: RoutineItem[];
  settings: UserSettings;
  onToggleTaskCompletion: (taskTitle: string, routineItem?: RoutineItem) => void;
  onSkipTask: (taskTitle: string, routineItem?: RoutineItem) => void;
  onUndoTask: (taskId: string) => void;
  onAddTaskRecord: (task: TaskRecord) => void;
  onRescheduleTask: (taskId: string, targetDate: string) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  taskRecords,
  routineItems,
  settings,
  onToggleTaskCompletion,
  onSkipTask,
  onUndoTask,
  onAddTaskRecord,
  onRescheduleTask,
}) => {
  const todayStr = getTodayDateString();
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed' | 'skipped' | 'overdue'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<CategoryType>('Personal');
  const [newDate, setNewDate] = useState(todayStr);
  const [newStartTime, setNewStartTime] = useState('14:00');
  const [newEndTime, setNewEndTime] = useState('15:00');
  const [newPriority, setNewPriority] = useState<PriorityType>('medium');

  // Categorize tasks including overdue detection
  const filteredTasks = taskRecords.filter((task) => {
    // Search match
    if (searchQuery && !task.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    // Category match
    if (categoryFilter !== 'all' && task.category !== categoryFilter) {
      return false;
    }

    // Overdue condition: date < today and status === 'pending'
    const isOverdue = task.date < todayStr && task.status === 'pending';

    if (statusFilter === 'overdue') return isOverdue;
    if (statusFilter === 'pending') return task.status === 'pending' && !isOverdue;
    if (statusFilter === 'completed') return task.status === 'completed';
    if (statusFilter === 'skipped') return task.status === 'skipped';

    return true;
  });

  // Calculate counters
  const totalCount = taskRecords.length;
  const completedCount = taskRecords.filter((t) => t.status === 'completed').length;
  const pendingCount = taskRecords.filter((t) => t.status === 'pending' && t.date >= todayStr).length;
  const overdueCount = taskRecords.filter((t) => t.status === 'pending' && t.date < todayStr).length;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const points = newPriority === 'high' ? 50 : newPriority === 'medium' ? 30 : 15;
    const newTask: TaskRecord = {
      id: 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: newTitle.trim(),
      category: newCategory,
      date: newDate,
      startTime: newStartTime,
      endTime: newEndTime,
      priority: newPriority,
      status: 'pending',
      pointsAwarded: points,
    };

    onAddTaskRecord(newTask);
    setShowAddModal(false);
    setNewTitle('');
  };

  const handleRescheduleAllOverdue = () => {
    const overdueTasks = taskRecords.filter((t) => t.status === 'pending' && t.date < todayStr);
    overdueTasks.forEach((t) => onRescheduleTask(t.id, todayStr));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-indigo-500" />
            Task Management & History
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Track daily completions, reschedule overdue subjects, and record ad-hoc tasks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {overdueCount > 0 && (
            <button
              onClick={handleRescheduleAllOverdue}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 text-xs font-semibold hover:bg-amber-500/20 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reschedule {overdueCount} Overdue to Today</span>
            </button>
          )}
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Single Task</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-1 overflow-x-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              statusFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            All Tasks ({totalCount})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              statusFilter === 'pending'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Pending ({pendingCount})
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              statusFilter === 'completed'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Completed ({completedCount})
          </button>
          {overdueCount > 0 && (
            <button
              onClick={() => setStatusFilter('overdue')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                statusFilter === 'overdue'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40'
              }`}
            >
              <AlertCircle className="w-3 h-3" />
              <span>Overdue ({overdueCount})</span>
            </button>
          )}
          <button
            onClick={() => setStatusFilter('skipped')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              statusFilter === 'skipped'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Skipped
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-48">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium"
          >
            <option value="all">All Categories</option>
            {Object.keys(CATEGORIES_CONFIG).map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Task List */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 md:p-6 shadow-sm">
        {filteredTasks.length === 0 ? (
          <div className="py-16 text-center space-y-2 text-slate-400">
            <CheckSquare className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
            <p className="text-sm font-semibold">No tasks matching your current filters.</p>
            <p className="text-xs">Try selecting a different status tab or category.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredTasks.map((task) => {
              const meta = getCategoryMeta(task.category);
              const isCompleted = task.status === 'completed';
              const isSkipped = task.status === 'skipped';
              const isOverdue = task.date < todayStr && task.status === 'pending';

              return (
                <div
                  key={task.id}
                  className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl border transition ${
                    isCompleted
                      ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800/60'
                      : isOverdue
                      ? 'bg-red-50/40 dark:bg-red-950/20 border-red-200 dark:border-red-900/40'
                      : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                    <button
                      onClick={() => {
                        if (isCompleted) {
                          onUndoTask(task.id);
                        } else {
                          onToggleTaskCompletion(task.title);
                        }
                      }}
                      className="mt-0.5 sm:mt-0 shrink-0 text-slate-300 dark:text-slate-600 hover:text-indigo-600 transition"
                      title={isCompleted ? 'Undo completion' : 'Mark completed (+XP)'}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-500/20" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`text-sm font-bold truncate ${
                            isCompleted ? 'line-through text-slate-400 dark:text-slate-500' : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {task.title}
                        </span>

                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${meta.bgLight} ${meta.textLight} ${meta.bgDark} ${meta.textDark} ${meta.borderColor}`}
                        >
                          {meta.label}
                        </span>

                        {isOverdue && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300">
                            OVERDUE
                          </span>
                        )}

                        {isSkipped && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                            SKIPPED
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                        <span className="flex items-center gap-1 font-mono">
                          <Calendar className="w-3 h-3" />
                          {task.date === todayStr ? 'Today' : task.date}
                        </span>
                        {task.startTime && (
                          <>
                            <span>•</span>
                            <span className="font-mono">
                              {formatTimeDisplay(task.startTime, settings.timeFormat)} - {formatTimeDisplay(task.endTime, settings.timeFormat)}
                            </span>
                          </>
                        )}
                        <span>•</span>
                        <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                          +{task.pointsAwarded} XP
                        </span>
                        {isCompleted && task.completedAt && (
                          <>
                            <span>•</span>
                            <span className="text-emerald-600 dark:text-emerald-400">
                              Completed {new Date(task.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-2 sm:mt-0 flex items-center justify-end gap-2 shrink-0">
                    {isOverdue && (
                      <button
                        onClick={() => onRescheduleTask(task.id, todayStr)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 text-xs font-semibold flex items-center gap-1"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Move to Today</span>
                      </button>
                    )}
                    {isCompleted && (
                      <button
                        onClick={() => onUndoTask(task.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="Undo"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {!isCompleted && !isSkipped && (
                      <button
                        onClick={() => onSkipTask(task.title)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40"
                        title="Skip"
                      >
                        <SkipForward className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Single Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              Add One-Off Task
            </h3>

            <form onSubmit={handleCreateTask} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Task Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Codeforces Editorial Read"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    {Object.keys(CATEGORIES_CONFIG).map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as PriorityType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="low">Low (15 XP)</option>
                    <option value="medium">Medium (30 XP)</option>
                    <option value="high">High (50 XP)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Scheduled Date
                </label>
                <input
                  type="date"
                  required
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={newStartTime}
                    onChange={(e) => setNewStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={newEndTime}
                    onChange={(e) => setNewEndTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
